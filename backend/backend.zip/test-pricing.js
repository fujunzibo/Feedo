import { createRequire } from 'module';
const require = createRequire(import.meta.url);
const { getSolPriceUsd } = require('./dist/services/pricing.js');

async function testPricing() {
  console.log('Testing SOL price fetching...');
  
  try {
    const price = await getSolPriceUsd();
    console.log(`✅ Successfully fetched SOL price: $${price}`);
  } catch (error) {
    console.error('❌ Failed to fetch SOL price:', error.message);
  }
}

testPricing();
