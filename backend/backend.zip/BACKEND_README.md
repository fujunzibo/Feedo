# 后端服务使用说明

> 本文档介绍 `backend` 服务的开发、构建、运行与故障排除。适用于本仓库开发环境与无源码的生产运行包两种场景。

## 一、技术栈与要求
- Node.js ≥ 18（推荐 18/20/22 LTS）
- npm ≥ 9
- TypeScript 编译输出为 ES2020 模块
- 数据库：Prisma（默认 SQLite，本地文件 `prisma/dev.db`）

## 二、目录结构（关键）
- `src/` TypeScript 源码（开发时）
- `dist/` 编译后的 JavaScript（生产运行）
- `prisma/` Prisma schema、migrations、SQLite 数据库
- `scripts/` 运行脚本（编译后位于 `dist/scripts/`）

## 三、环境变量
在仓库根目录或 `backend/` 可使用 `.env`。示例请参考仓库根目录的 `.env.example`。
常见变量（按项目实际为准）：
- 数据库与基础
  - `DATABASE_URL`（默认可为 `file:./backend/prisma/dev.db` 或在 backend 目录下为 `file:./prisma/dev.db`）
- Solana/第三方
  - `RPC_URL`、`HELIUS_API_KEY`、`JUPITER_BASE`
- 钱包/密钥（如项目需要）
  - `TREASURY_WALLET`、`TARGET_WALLET`、`DONATION_WALLET`
  - `LOCAL_PRIVATE_KEY`、`TARGET_PRIVATE_KEY`（请安全保管）

注意：生产环境切勿提交真实密钥到仓库。

## 四、开发环境
1) 安装依赖
```bash
cd backend
npm install
```

2) 生成 Prisma Client（每次变更 schema 后执行）
```bash
npx prisma generate
```

3) 运行迁移（如需）
```bash
npx prisma migrate dev
```

4) 启动开发（按项目脚本为准）
```bash
npm run dev
```

## 五、构建与本地生产运行（含源码场景）
1) 构建 TypeScript
```bash
cd backend
npm run build
```

2) 启动（本地生产）
```bash
# 确保 .env 配置正确
node dist/index.js
```

## 六、无源码生产运行包使用
如果你使用的是已打包好的“无源码”生产包：

- 一键启动（推荐）
```bash
cd production-build
node start-production.js
```
说明：`start-production.js` 位于 `production-build/` 目录下，请不要在仓库根目录直接 `node start-production.js`，否则会出现“Cannot find module '.../start-production.js'”错误。

- 仅启动后端（不启代理）
```bash
cd production-build/backend
node dist/index.js
```

## 七、常用脚本（编译后）
以下脚本在编译后位于 `backend/dist/scripts/` 目录，示例：
```bash
# 示例，根据实际存在的脚本名称执行
node dist/scripts/checkKeypairMatch.js
node dist/scripts/fixKeypairMismatch.js
node dist/scripts/generateTreasuryKeypair.js
node dist/scripts/initTreasury.js
node dist/scripts/setupTreasury.js
node dist/scripts/testExchangeAPI.js
node dist/scripts/testExchangeRate.js
node dist/scripts/verifyExchangeRate.js
```

## 八、服务与健康检查
- 默认端口：`4000`（如项目内有修改，以实际为准）
- 健康检查（如已实现）：
```bash
curl http://localhost:4000/api/health
```

## 九、Prisma 与数据库
- 生成 Client：`npx prisma generate`
- 应用迁移（生产）：`npx prisma migrate deploy`
- 查看数据库（SQLite 示例）：`npx prisma studio`

路径提示：无源码包中 SQLite 路径通常是 `production-build/backend/prisma/dev.db`。

## 十、故障排除
- 启动时报找不到 `start-production.js`
  - 请在 `production-build/` 目录执行：`node start-production.js`
- Windows PowerShell 无法用 `&&` 链接命令
  - 请分步执行：`cd backend` 与 `npm ...` 分别运行
- TypeScript 报 `TS1343 import.meta` 错误
  - 确保 `backend/tsconfig.json` 的 `module` 与 `target` 为 `ES2020`，`moduleResolution` 为 `node`
- `npm ci` 报 lockfile 不一致
  - 使用 `npm install --omit=dev` 安装生产依赖，或先更新 lockfile 再 `npm ci`
- Prisma Client 找不到/引擎错误
  - 先执行 `npx prisma generate`，生产环境用 `npx prisma migrate deploy`

## 十一、日志与端口占用
- 直接运行的日志输出在控制台
- 端口占用检查（Windows）：
```powershell
netstat -ano | findstr :4000
```

---
如需前后端联动与代理运行，请参考仓库根目录的部署文档与 `production-build/start-production.js` 行为。

## 十二、API 接口概览
以下为从 `backend/src/index.ts` 中汇总的主要 API 路径（简要说明，具体入参与响应以代码实现为准）：

- GET `/api/health`：健康检查
- GET `/api/wallet-assets`：查询钱包资产汇总
- GET `/api/dashboard`：仪表盘数据
- GET `/api/export-csv`：导出 CSV 数据
- POST `/api/debug/trigger-swap-donate`：调试触发 阈值换币 + 自动捐赠
- POST `/api/debug/trigger-full-workflow`：调试触发完整流程（1%转账 + 阈值换币 + 自动捐赠）
- POST `/api/cache/invalidate`：手动失效缓存
- POST `/api/force-update-balances`：强制刷新余额
- POST `/api/upload/video`：上传视频，表单字段 `video`
- POST `/api/upload/media`：上传图片/视频，表单字段 `media`
- GET `/api/media`：获取媒体列表
- POST `/api/debug/monthly-transfer`：独立触发每月 1% 转账
- POST `/api/debug/threshold-swap`：独立触发阈值换币
- POST `/api/debug/auto-donation`：独立触发自动捐赠
- GET `/api/exchange/tokens`：查询可交换代币列表
- GET `/api/exchange/price`：查询代币价格
- GET `/api/exchange/quote`：获取兑换报价
- POST `/api/exchange/swap`：提交兑换（模拟/路由）
- POST `/api/swap/execute`：执行真实兑换
- GET `/api/swap/rate`：查询兑换费率/汇率
- GET `/api/wallet/:walletId/balance/:token`：查询指定钱包指定代币余额
- GET `/api/treasury/balance`：查询金库余额
- GET `/api/wallets/balances`：批量查询钱包余额

说明：
- 带文件上传的接口需使用 `multipart/form-data`。
- 某些调试接口可能仅用于开发/内部使用，生产环境请按需开放并做好鉴权。
