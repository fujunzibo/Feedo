import WebSocket from 'ws';
import { logger } from '../lib/logger';
import { prisma } from '../lib/prisma';
import { getConnection } from '../solana/clients';
import { getSolPriceUsd } from './pricing';
import { getMint, getAccount, getAssociatedTokenAddress } from '@solana/spl-token';
import { PublicKey, LAMPORTS_PER_SOL } from '@solana/web3.js';

interface WalletBalance {
  id: string;
  name: string;
  type: string;
  address: string;
  solBalance: number;
  solBalanceUsd: number;
  tokenBalance: number;
  tokenBalanceUsd: number;
  totalUsd: number;
  timestamp: string;
}

class WebSocketService {
  private wss: WebSocket.Server;
  private clients: Set<WebSocket> = new Set();
  private balanceInterval: NodeJS.Timeout | null = null;
  private readonly UPDATE_INTERVAL = 10000; // 10秒更新一次，提高响应速度

  constructor(port: number) {
    try {
      this.wss = new WebSocket.Server({ port });
      this.setupWebSocketServer();
      this.startBalanceUpdates();
      logger.info(`WebSocket server started on port ${port}`);
    } catch (error) {
      logger.error(`Failed to start WebSocket server on port ${port}:`, error);
      throw error;
    }
  }

  private setupWebSocketServer() {
    this.wss.on('connection', (ws: WebSocket) => {
      logger.info('New WebSocket client connected');
      this.clients.add(ws);

      // 发送欢迎消息
      ws.send(JSON.stringify({
        type: 'connected',
        message: 'Connected to balance update service',
        timestamp: new Date().toISOString()
      }));

      // 立即发送当前余额
      this.sendCurrentBalances(ws);

      ws.on('close', () => {
        logger.info('WebSocket client disconnected');
        this.clients.delete(ws);
      });

      ws.on('error', (error) => {
        logger.error('WebSocket error:', error);
        this.clients.delete(ws);
      });

      // 处理客户端消息
      ws.on('message', (message) => {
        try {
          const data = JSON.parse(message.toString());
          this.handleClientMessage(ws, data);
        } catch (error) {
          logger.error('Invalid WebSocket message:', error);
        }
      });
    });
  }

  private async handleClientMessage(ws: WebSocket, data: any) {
    switch (data.type) {
      case 'request_balance':
        // 客户端请求立即更新余额
        await this.sendCurrentBalances(ws);
        break;
      case 'ping':
        // 心跳检测
        ws.send(JSON.stringify({ type: 'pong', timestamp: new Date().toISOString() }));
        break;
      default:
        logger.warn('Unknown message type:', data.type);
    }
  }

  private startBalanceUpdates() {
    // 立即执行一次更新，确保新连接的客户端能快速获得数据
    this.broadcastBalanceUpdate();
    
    this.balanceInterval = setInterval(async () => {
      if (this.clients.size > 0) {
        await this.broadcastBalanceUpdate();
      }
    }, this.UPDATE_INTERVAL);
  }

  private lastBalances: WalletBalance[] = [];

  private async broadcastBalanceUpdate() {
    try {
      const balances = await this.fetchWalletBalances();
      
      // 检查余额是否真的发生了变化
      const hasChanged = this.hasBalancesChanged(balances);
      
      if (!hasChanged) {
        logger.info('No balance changes detected, skipping broadcast');
        return;
      }

      const message = JSON.stringify({
        type: 'balance_update',
        data: balances,
        timestamp: new Date().toISOString()
      });

      // 广播给所有连接的客户端
      this.clients.forEach((client) => {
        if (client.readyState === WebSocket.OPEN) {
          client.send(message);
        } else {
          // 清理断开的连接
          this.clients.delete(client);
        }
      });

      this.lastBalances = balances;
      logger.info(`Broadcasted balance update to ${this.clients.size} clients`);
    } catch (error) {
      logger.error('Error broadcasting balance update:', error);
    }
  }

  private hasBalancesChanged(newBalances: WalletBalance[]): boolean {
    if (this.lastBalances.length === 0) {
      return true; // 首次更新
    }

    if (newBalances.length !== this.lastBalances.length) {
      return true; // 钱包数量变化
    }

    // 检查每个钱包的余额是否发生变化
    for (let i = 0; i < newBalances.length; i++) {
      const newBalance = newBalances[i];
      const lastBalance = this.lastBalances.find(p => p.id === newBalance.id);

      if (!lastBalance) {
        return true; // 新钱包
      }

      // 检查SOL余额变化（允许0.000001的误差）
      if (Math.abs(newBalance.solBalance - lastBalance.solBalance) > 0.000001) {
        logger.info(`SOL balance changed for ${newBalance.name}: ${lastBalance.solBalance} -> ${newBalance.solBalance}`);
        return true;
      }

      // 检查代币余额变化（允许0.01的误差）
      if (Math.abs(newBalance.tokenBalance - lastBalance.tokenBalance) > 0.01) {
        logger.info(`Token balance changed for ${newBalance.name}: ${lastBalance.tokenBalance} -> ${newBalance.tokenBalance}`);
        return true;
      }

      // 检查总价值变化（允许0.01的误差）
      if (Math.abs(newBalance.totalUsd - lastBalance.totalUsd) > 0.01) {
        logger.info(`Total USD changed for ${newBalance.name}: ${lastBalance.totalUsd} -> ${newBalance.totalUsd}`);
        return true;
      }
    }

    return false; // 没有变化
  }

  private async sendCurrentBalances(ws: WebSocket) {
    try {
      const balances = await this.fetchWalletBalances();
      ws.send(JSON.stringify({
        type: 'balance_update',
        data: balances,
        timestamp: new Date().toISOString()
      }));
    } catch (error) {
      logger.error('Error sending current balances:', error);
      ws.send(JSON.stringify({
        type: 'error',
        message: 'Failed to fetch balances',
        timestamp: new Date().toISOString()
      }));
    }
  }

  private async fetchWalletBalances(): Promise<WalletBalance[]> {
    try {
      const wallets = await prisma.wallet.findMany();
      const connection = getConnection();
      const mintAddress = '5n8sDdBMjsLwtLRVpcFrhFcGa4cXdaUiWKKwNyos8fFK'; // FEEDO token

      // 获取SOL价格
      const solPriceUsd = await getSolPriceUsd();
      const tokenPriceUsd = solPriceUsd / 1000; // FEEDO代币价格 = SOL价格 / 1000

      // 获取mintInfo
      const mintInfo = await getMint(connection, new PublicKey(mintAddress));
      
      // 批量获取所有钱包的SOL余额
      const walletPubkeys = wallets.map(w => new PublicKey(w.address));
      const solBalances = await Promise.all(
        walletPubkeys.map(pubkey => connection.getBalance(pubkey))
      );

      // 批量获取所有钱包的代币账户信息
      const tokenAccounts = await Promise.all(
        walletPubkeys.map(async (pubkey) => {
          try {
            const tokenAccount = await getAssociatedTokenAddress(
              new PublicKey(mintAddress),
              pubkey
            );
            const accountInfo = await getAccount(connection, tokenAccount);
            return {
              accountInfo,
              tokenAccount
            };
          } catch (error) {
            return {
              accountInfo: null,
              tokenAccount: null,
              error
            };
          }
        })
      );

      // 构建结果
      const walletBalances: WalletBalance[] = wallets.map((wallet, index) => {
        try {
          const solBalance = solBalances[index] / LAMPORTS_PER_SOL;
          
          let tokenBalance = 0;
          if (tokenAccounts[index].accountInfo) {
            tokenBalance = Number(tokenAccounts[index].accountInfo!.amount) / Math.pow(10, mintInfo.decimals);
          }
          
          return {
            id: wallet.id,
            name: wallet.name,
            type: wallet.type,
            address: wallet.address,
            solBalance,
            solBalanceUsd: solBalance * solPriceUsd,
            tokenBalance,
            tokenBalanceUsd: tokenBalance * tokenPriceUsd,
            totalUsd: (solBalance * solPriceUsd) + (tokenBalance * tokenPriceUsd),
            timestamp: new Date().toISOString()
          };
        } catch (error) {
          logger.error(`Error processing wallet ${wallet.address}:`, error);
          return {
            id: wallet.id,
            name: wallet.name,
            type: wallet.type,
            address: wallet.address,
            solBalance: 0,
            solBalanceUsd: 0,
            tokenBalance: 0,
            tokenBalanceUsd: 0,
            totalUsd: 0,
            timestamp: new Date().toISOString()
          };
        }
      });

      return walletBalances;
    } catch (error) {
      logger.error('Error fetching wallet balances:', error);
      throw error;
    }
  }

  // 手动触发余额更新（用于交易后立即更新）
  public async triggerBalanceUpdate() {
    await this.broadcastBalanceUpdate();
  }

  // 停止服务
  public stop() {
    if (this.balanceInterval) {
      clearInterval(this.balanceInterval);
    }
    this.wss.close();
    logger.info('WebSocket service stopped');
  }
}

export const webSocketService = new WebSocketService(4001);
