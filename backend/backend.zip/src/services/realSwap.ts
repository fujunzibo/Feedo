import { 
  Connection, 
  PublicKey, 
  Transaction, 
  SystemProgram, 
  LAMPORTS_PER_SOL,
  Keypair,
  sendAndConfirmTransaction,
  TransactionInstruction
} from '@solana/web3.js';
import { 
  createTransferInstruction, 
  getAssociatedTokenAddress, 
  getAccount,
  getMint,
  createAssociatedTokenAccountInstruction,
  TOKEN_PROGRAM_ID,
  ASSOCIATED_TOKEN_PROGRAM_ID
} from '@solana/spl-token';
import { getConnection } from '../solana/clients';
import { logger } from '../lib/logger';
import { prisma } from '../lib/prisma';
import { appEnv } from '../config';
import { getQuote, buildSwapTransaction } from './jupiter';
import { treasuryBalanceService } from './treasuryBalance';

// FEEDO代币的mint地址
const FEEDO_MINT = new PublicKey('5n8sDdBMjsLwtLRVpcFrhFcGa4cXdaUiWKKwNyos8fFK');
const SOL_MINT = new PublicKey('So11111111111111111111111111111111111111112');

export interface SwapRequest {
  fromWalletId: string;
  toWalletId: string;
  fromToken: 'SOL' | 'FEEDO';
  toToken: 'SOL' | 'FEEDO';
  amount: number;
  slippage?: number;
}

export interface SwapResult {
  success: boolean;
  transactionSignature?: string;
  error?: string;
  fromAmount?: number;
  toAmount?: number;
  priceImpact?: number;
}

export class RealSwapService {
  private connection: Connection;
  private signer: Keypair | null = null;

  constructor() {
    this.connection = getConnection();
    this.initializeSigner();
  }

  /**
   * 初始化签名者
   */
  private initializeSigner() {
    try {
      logger.info('Initializing signer...');
      logger.info('appEnv.localPrivateKey:', appEnv.localPrivateKey);
      
      if (appEnv.localPrivateKey) {
        // 从环境变量中获取私钥
        const privateKeyArray = JSON.parse(appEnv.localPrivateKey);
        this.signer = Keypair.fromSecretKey(new Uint8Array(privateKeyArray));
        logger.info('Signer initialized from environment variable');
        logger.info('Signer public key:', this.signer.publicKey.toBase58());
      } else {
        logger.warn('No private key found in environment variables. Swaps will be simulated.');
      }
    } catch (error) {
      logger.error('Failed to initialize signer:', error);
    }
  }

  /**
   * 根据钱包类型获取对应的私钥
   */
  private getPrivateKeyForWallet(walletType: string): Keypair | null {
    try {
      let privateKeyString: string | undefined;

      switch (walletType) {
        case 'treasury':
          privateKeyString = appEnv.treasuryPrivateKey;
          break;
        case 'target':
          privateKeyString = appEnv.targetPrivateKey;
          break;
        case 'donation':
          privateKeyString = appEnv.donationPrivateKey;
          break;
        default:
          privateKeyString = appEnv.localPrivateKey;
      }

      if (!privateKeyString) {
        logger.error(`No private key found for wallet type: ${walletType}`);
        return null;
      }

      const privateKeyArray = JSON.parse(privateKeyString);
      const keypair = Keypair.fromSecretKey(new Uint8Array(privateKeyArray));
      logger.info(`Private key loaded for ${walletType} wallet: ${keypair.publicKey.toBase58()}`);
      return keypair;

    } catch (error) {
      logger.error(`Failed to load private key for ${walletType} wallet:`, error);
      return null;
    }
  }

  /**
   * 执行代币兑换
   */
  async executeSwap(request: SwapRequest): Promise<SwapResult> {
    try {
      logger.info('Starting treasury-based swap execution:', request);

      // 获取treasury钱包信息
      const treasuryWallet = await prisma.wallet.findFirst({
        where: { type: 'treasury' }
      });

      if (!treasuryWallet) {
        return {
          success: false,
          error: 'Treasury wallet not found'
        };
      }

      // 获取Treasury钱包的私钥
      const treasuryKeypair = this.getPrivateKeyForWallet('treasury');
      if (!treasuryKeypair) {
        return {
          success: false,
          error: 'Treasury private key not found. Please configure TREASURY_PRIVATE_KEY in environment variables.'
        };
      }

      // 检查Treasury私钥是否与钱包地址匹配
      if (treasuryKeypair.publicKey.toBase58() !== treasuryWallet.address) {
        return {
          success: false,
          error: `❌ Treasury private key mismatch!\n` +
                 `Private key public key: ${treasuryKeypair.publicKey.toBase58()}\n` +
                 `Treasury wallet address: ${treasuryWallet.address}\n\n` +
                 `Please check your TREASURY_PRIVATE_KEY in .env file.`
        };
      }

      // 获取源钱包信息（用户钱包）
      const fromWallet = await prisma.wallet.findUnique({
        where: { id: request.fromWalletId }
      });

      if (!fromWallet) {
        return {
          success: false,
          error: 'Source wallet not found'
        };
      }

      // 获取目标钱包信息
      const toWallet = await prisma.wallet.findUnique({
        where: { id: request.toWalletId }
      });

      if (!toWallet) {
        return {
          success: false,
          error: 'Target wallet not found'
        };
      }

      const fromWalletPubkey = new PublicKey(fromWallet.address);
      const toWalletPubkey = new PublicKey(toWallet.address);

      // 检查用户钱包余额
      const balanceCheck = await this.checkBalances(fromWalletPubkey, request.fromToken, request.amount);
      if (!balanceCheck.sufficient) {
        return {
          success: false,
          error: `Insufficient ${request.fromToken} balance. Available: ${balanceCheck.available}, Required: ${request.amount}`
        };
      }

      // 检查treasury是否有足够的代币进行兑换
      const toToken = request.fromToken === 'SOL' ? 'FEEDO' : 'SOL';
      const requiredTreasuryAmount = request.fromToken === 'SOL' 
        ? request.amount * 1000 // 1 SOL = 1000 FEEDO
        : request.amount / 1000; // 1000 FEEDO = 1 SOL

      const treasuryBalanceCheck = await treasuryBalanceService.checkTreasurySufficientBalance(
        toToken as 'SOL' | 'FEEDO',
        requiredTreasuryAmount
      );

      if (!treasuryBalanceCheck.sufficient) {
        return {
          success: false,
          error: `Insufficient ${toToken} balance in treasury. Available: ${treasuryBalanceCheck.available}, Required: ${requiredTreasuryAmount}`
        };
      }

      // 使用treasury作为资金池的兑换系统
      logger.info('Using treasury-based swap system');
      return await this.executeDirectChainSwap(request, fromWalletPubkey, toWalletPubkey);

    } catch (error) {
      logger.error('Treasury-based swap execution failed:', error);
      return {
        success: false,
        error: error instanceof Error ? error.message : 'Unknown error'
      };
    }
  }

  /**
   * 使用Jupiter DEX执行真实兑换
   */
  private async executeJupiterSwap(
    request: SwapRequest,
    fromWallet: PublicKey,
    toWallet: PublicKey
  ): Promise<SwapResult> {
    try {
      logger.info('Executing Jupiter DEX swap:', {
        fromToken: request.fromToken,
        toToken: request.toToken,
        amount: request.amount
      });

      // 转换代币标识符
      const inputMint = request.fromToken === 'SOL' ? SOL_MINT.toBase58() : FEEDO_MINT.toBase58();
      const outputMint = request.toToken === 'SOL' ? SOL_MINT.toBase58() : FEEDO_MINT.toBase58();
      
      // 转换金额（SOL需要转换为lamports）
      const amount = request.fromToken === 'SOL' 
        ? Math.floor(request.amount * LAMPORTS_PER_SOL).toString()
        : Math.floor(request.amount * 1e6).toString(); // FEEDO假设6位小数

      logger.info('Jupiter swap parameters:', {
        inputMint,
        outputMint,
        amount,
        slippageBps: request.slippage || 50
      });

      // 获取Jupiter报价
      const quote = await getQuote(
        inputMint,
        outputMint,
        amount,
        request.slippage || 50
      );

      logger.info('Jupiter quote received:', {
        routePlan: quote.routePlan?.length || 0,
        otherAmountThreshold: quote.otherAmountThreshold
      });

      // 构建交换交易
      const swapRequest = {
        quoteResponse: quote,
        userPublicKey: fromWallet.toBase58(),
        wrapAndUnwrapSol: true,
        useSharedAccounts: true,
        feeAccount: null,
        trackingAccount: null,
        computeUnitPriceMicroLamports: null,
        asLegacyTransaction: false,
        useTokenLedger: false,
        destinationTokenAccount: toWallet.toBase58()
      };

      const swapTransaction = await buildSwapTransaction(swapRequest);
      
      logger.info('Jupiter swap transaction built successfully');

      // 反序列化交易
      const transaction = Transaction.from(Buffer.from(swapTransaction.swapTransaction, 'base64'));
      
      // 设置交易费用支付者
      transaction.feePayer = fromWallet;

      // 发送并确认交易
      const signature = await sendAndConfirmTransaction(
        this.connection,
        transaction,
        [this.signer!],
        {
          commitment: 'confirmed',
          skipPreflight: false
        }
      );

      logger.info('Jupiter swap transaction confirmed:', signature);

      // 计算实际兑换数量
      const actualToAmount = request.fromToken === 'SOL' 
        ? parseFloat(quote.otherAmountThreshold) / 1e6 // FEEDO有6位小数
        : parseFloat(quote.otherAmountThreshold) / LAMPORTS_PER_SOL; // SOL

      // 记录交易到数据库
      await this.recordSwapTransaction(request, signature);

      return {
        success: true,
        transactionSignature: signature,
        fromAmount: request.amount,
        toAmount: actualToAmount
      };

    } catch (error) {
      logger.error('Jupiter swap failed:', error);
      return {
        success: false,
        error: error instanceof Error ? error.message : 'Jupiter swap failed'
      };
    }
  }

  /**
   * 获取钱包代币余额
   */
  async getWalletTokenBalance(walletId: string, token: 'SOL' | 'FEEDO'): Promise<number> {
    try {
      const wallet = await prisma.wallet.findUnique({
        where: { id: walletId }
      });

      if (!wallet) {
        return 0;
      }

      const walletPubkey = new PublicKey(wallet.address);

      if (token === 'SOL') {
        const balance = await this.connection.getBalance(walletPubkey);
        return balance / LAMPORTS_PER_SOL;
      } else {
        const feudoTokenAccount = await getAssociatedTokenAddress(
          FEEDO_MINT,
          walletPubkey,
          true
        );

        try {
          const accountInfo = await getAccount(this.connection, feudoTokenAccount);
          const mintInfo = await getMint(this.connection, FEEDO_MINT);
          return Number(accountInfo.amount) / Math.pow(10, mintInfo.decimals);
        } catch (error) {
          return 0;
        }
      }
    } catch (error) {
      logger.error('Failed to get wallet token balance:', error);
      return 0;
    }
  }

  /**
   * 获取兑换汇率 (通过Jupiter获取实时汇率)
   */
  async getSwapRate(fromToken: 'SOL' | 'FEEDO', toToken: 'SOL' | 'FEEDO'): Promise<number> {
    try {
      const inputMint = fromToken === 'SOL' ? SOL_MINT.toBase58() : FEEDO_MINT.toBase58();
      const outputMint = toToken === 'SOL' ? SOL_MINT.toBase58() : FEEDO_MINT.toBase58();
      
      // 使用1个代币作为基准获取汇率
      const amount = fromToken === 'SOL' 
        ? LAMPORTS_PER_SOL.toString() // 1 SOL
        : (1e6).toString(); // 1 FEEDO

      const quote = await getQuote(inputMint, outputMint, amount, 50);
      
      // 计算汇率
      const rate = parseFloat(quote.otherAmountThreshold) / parseFloat(amount);
      
      // 直接返回固定汇率，因为Jupiter可能无法正确处理我们的代币对
      if (fromToken === 'SOL' && toToken === 'FEEDO') {
        return 1000; // 1 SOL = 1000 FEEDO
      } else if (fromToken === 'FEEDO' && toToken === 'SOL') {
        return 0.001; // 1000 FEEDO = 1 SOL
      }
      
      return rate;
      
    } catch (error) {
      logger.error('Failed to get swap rate from Jupiter:', error);
      
      // 返回固定汇率作为后备
      if (fromToken === 'SOL' && toToken === 'FEEDO') {
        return 1000; // 1 SOL = 1000 FEEDO
      } else if (fromToken === 'FEEDO' && toToken === 'SOL') {
        return 0.001; // 1000 FEEDO = 1 SOL
      }
      return 0;
    }
  }

  /**
   * 检查钱包余额是否充足
   */
  private async checkBalances(
    walletPubkey: PublicKey,
    token: 'SOL' | 'FEEDO',
    requiredAmount: number
  ): Promise<{ sufficient: boolean; available: number }> {
    try {
      if (token === 'SOL') {
        const balance = await this.connection.getBalance(walletPubkey);
        const solBalance = balance / LAMPORTS_PER_SOL;
        return {
          sufficient: solBalance >= requiredAmount,
          available: solBalance
        };
      } else {
        // FEEDO代币
        const feudoTokenAccount = await getAssociatedTokenAddress(
          FEEDO_MINT,
          walletPubkey,
          true
        );

        try {
          const accountInfo = await getAccount(this.connection, feudoTokenAccount);
          const mintInfo = await getMint(this.connection, FEEDO_MINT);
          const feudoBalance = Number(accountInfo.amount) / Math.pow(10, mintInfo.decimals);
          
          return {
            sufficient: feudoBalance >= requiredAmount,
            available: feudoBalance
          };
        } catch (error) {
          // 代币账户不存在
          return {
            sufficient: false,
            available: 0
          };
        }
      }
    } catch (error) {
      logger.error('Balance check failed:', error);
      return {
        sufficient: false,
        available: 0
      };
    }
  }

  /**
   * 使用Treasury作为资金池的兑换系统
   */
  private async executeDirectChainSwap(
    request: SwapRequest,
    fromWallet: PublicKey,
    toWallet: PublicKey
  ): Promise<SwapResult> {
    try {
      logger.info('Executing treasury-based swap:', {
        fromToken: request.fromToken,
        toToken: request.toToken,
        amount: request.amount
      });

      // 获取treasury钱包
      const treasuryWallet = await prisma.wallet.findFirst({
        where: { type: 'treasury' }
      });

      if (!treasuryWallet) {
        return {
          success: false,
          error: 'Treasury wallet not found'
        };
      }

      const treasuryPubkey = new PublicKey(treasuryWallet.address);
      const transaction = new Transaction();

      if (request.fromToken === 'SOL' && request.toToken === 'FEEDO') {
        // SOL -> FEEDO: 用户SOL转入treasury，treasury FEEDO转给用户
        const lamports = Math.floor(request.amount * LAMPORTS_PER_SOL);
        const feudoAmount = Math.floor(request.amount * 1000 * 1e6); // 1000 FEEDO per SOL

        // 1. 用户SOL转入treasury
        const transferSolInstruction = SystemProgram.transfer({
          fromPubkey: fromWallet,
          toPubkey: treasuryPubkey,
          lamports: lamports
        });
        transaction.add(transferSolInstruction);

        // 2. 创建用户FEEDO代币账户（如果不存在）
        const userFeudoAccount = await getAssociatedTokenAddress(
          FEEDO_MINT,
          toWallet,
          true
        );

        try {
          await getAccount(this.connection, userFeudoAccount);
        } catch (error) {
          // 代币账户不存在，创建它
          const createAccountInstruction = createAssociatedTokenAccountInstruction(
            fromWallet, // payer
            userFeudoAccount, // ata
            toWallet, // owner
            FEEDO_MINT // mint
          );
          transaction.add(createAccountInstruction);
        }

        // 3. 从treasury转移FEEDO给用户
        const treasuryFeudoAccount = await getAssociatedTokenAddress(
          FEEDO_MINT,
          treasuryPubkey,
          true
        );

        // 检查treasury是否有足够的FEEDO代币
        try {
          const treasuryAccountInfo = await getAccount(this.connection, treasuryFeudoAccount);
          const currentBalance = Number(treasuryAccountInfo.amount);
          
          if (currentBalance < feudoAmount) {
            return {
              success: false,
              error: `Insufficient FEEDO balance in treasury. Available: ${currentBalance / 1e6}, Required: ${feudoAmount / 1e6}`
            };
          }

          // 从treasury转移FEEDO给用户
          const transferTokenInstruction = createTransferInstruction(
            treasuryFeudoAccount,
            userFeudoAccount,
            treasuryPubkey, // treasury是owner
            feudoAmount,
            [],
            TOKEN_PROGRAM_ID
          );
          transaction.add(transferTokenInstruction);

        } catch (error) {
          return {
            success: false,
            error: `Treasury FEEDO account not found or error: ${error}`
          };
        }

      } else if (request.fromToken === 'FEEDO' && request.toToken === 'SOL') {
        // FEEDO -> SOL: 用户FEEDO转入treasury，treasury SOL转给用户
        const feudoAmount = request.amount;
        const solAmount = feudoAmount / 1000; // 1000 FEEDO = 1 SOL
        const lamports = Math.floor(solAmount * LAMPORTS_PER_SOL);

        // 1. 检查用户FEEDO代币余额
        const userFeudoAccount = await getAssociatedTokenAddress(
          FEEDO_MINT,
          fromWallet,
          true
        );

        try {
          const accountInfo = await getAccount(this.connection, userFeudoAccount);
          const mintInfo = await getMint(this.connection, FEEDO_MINT);
          const currentBalance = Number(accountInfo.amount) / Math.pow(10, mintInfo.decimals);

          if (currentBalance < feudoAmount) {
            return {
              success: false,
              error: `Insufficient FEEDO balance. Available: ${currentBalance}, Required: ${feudoAmount}`
            };
          }

          // 2. 用户FEEDO转入treasury
          const treasuryFeudoAccount = await getAssociatedTokenAddress(
            FEEDO_MINT,
            treasuryPubkey,
            true
          );

          const feudoAmountRaw = Math.floor(feudoAmount * Math.pow(10, mintInfo.decimals));
          
          const transferTokenInstruction = createTransferInstruction(
            userFeudoAccount,
            treasuryFeudoAccount,
            fromWallet, // 用户是owner
            feudoAmountRaw,
            [],
            TOKEN_PROGRAM_ID
          );
          transaction.add(transferTokenInstruction);

          // 3. treasury SOL转给用户
          const transferSolInstruction = SystemProgram.transfer({
            fromPubkey: treasuryPubkey,
            toPubkey: toWallet,
            lamports: lamports
          });
          transaction.add(transferSolInstruction);

        } catch (error) {
          return {
            success: false,
            error: `User FEEDO account not found or error: ${error}`
          };
        }
      } else {
        return {
          success: false,
          error: 'Unsupported swap pair for treasury-based swap'
        };
      }

      // 获取两个签名者：用户和Treasury
      const treasuryKeypair = this.getPrivateKeyForWallet('treasury');
      if (!treasuryKeypair) {
        return {
          success: false,
          error: 'Treasury private key not available for signing transaction'
        };
      }

      // 获取用户私钥（根据fromWallet地址匹配）
      const userKeypair = this.getPrivateKeyForWallet('target'); // 假设用户是target钱包
      if (!userKeypair) {
        return {
          success: false,
          error: 'User private key not available for signing transaction'
        };
      }

      // 设置feePayer为用户（fromWallet）
      transaction.feePayer = fromWallet;

      // 发送真实的链上交易（双签）
      const signature = await sendAndConfirmTransaction(
        this.connection,
        transaction,
        [userKeypair, treasuryKeypair],
        {
          commitment: 'confirmed',
          skipPreflight: false
        }
      );

      logger.info('Treasury-based swap transaction confirmed:', signature);

      // 计算兑换数量
      const toAmount = request.fromToken === 'SOL' 
        ? request.amount * 1000 // 1 SOL = 1000 FEEDO
        : request.amount / 1000; // 1000 FEEDO = 1 SOL

      // 记录交易
      await this.recordSwapTransaction(request, signature);

      return {
        success: true,
        transactionSignature: signature,
        fromAmount: request.amount,
        toAmount: toAmount
      };

    } catch (error) {
      logger.error('Treasury-based swap failed:', error);
      return {
        success: false,
        error: error instanceof Error ? error.message : 'Treasury-based swap failed'
      };
    }
  }

  /**
   * 记录兑换交易
   */
  private async recordSwapTransaction(request: SwapRequest, txSig: string) {
    try {
      await prisma.txRecord.create({
        data: {
          kind: 'swap',
          txSig: txSig,
          status: 'success',
          amountUi: request.amount,
          fromAddress: (await prisma.wallet.findUnique({ where: { id: request.fromWalletId } }))?.address,
          toAddress: (await prisma.wallet.findUnique({ where: { id: request.toWalletId } }))?.address,
          metadata: JSON.stringify({
            fromToken: request.fromToken,
            toToken: request.toToken,
            amount: request.amount,
            slippage: request.slippage,
            fromWalletId: request.fromWalletId,
            toWalletId: request.toWalletId,
            dex: 'jupiter'
          })
        }
      });
      logger.info('Swap transaction recorded successfully.');
    } catch (error) {
      logger.error('Failed to record swap transaction:', error);
    }
  }
}

export const realSwapService = new RealSwapService();