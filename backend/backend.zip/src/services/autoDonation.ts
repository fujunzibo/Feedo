import { Connection, PublicKey, Transaction, SystemProgram, LAMPORTS_PER_SOL, Keypair } from '@solana/web3.js';
import { getConnection, getSigner } from '../solana/clients';
import { appEnv } from '../config';
import bs58 from 'bs58';
import { prisma } from '../lib/prisma';
import { logger } from '../lib/logger';
import { getSolPriceUsd } from './pricing';
import pRetry from 'p-retry';
import { randomUUID } from 'crypto';

export interface DonationResult {
  success: boolean;
  txSignature?: string;
  amount?: number;
  usdValue?: number;
  error?: string;
}

export async function executeAutoDonation(): Promise<DonationResult> {
  const connection = getConnection();

  // 获取目标钱包私钥用于签名
  if (!appEnv.targetPrivateKey) {
    throw new Error('TARGET_PRIVATE_KEY not set');
  }
  let secret: Uint8Array;
  const pk = appEnv.targetPrivateKey.trim();
  if (pk.startsWith('[') && pk.endsWith(']')) {
    const arr = JSON.parse(pk);
    if (!Array.isArray(arr) || !arr.every((n: unknown) => typeof n === 'number')) {
      throw new Error('JSON private key must be an array of numbers');
    }
    secret = new Uint8Array(arr as number[]);
  } else {
    try {
      secret = bs58.decode(pk);
    } catch (e) {
      if (pk.length === 128) {
        const hex = pk;
        secret = new Uint8Array(hex.match(/.{1,2}/g)!.map(b => parseInt(b, 16)));
      } else {
        throw new Error(`Invalid private key format. Expected JSON array/base58/128-char hex, got ${pk.length} chars`);
      }
    }
  }
  const targetKeypair = secret.length === 32
    ? Keypair.fromSeed(secret)
    : secret.length === 64
      ? Keypair.fromSecretKey(secret)
      : (() => { throw new Error(`Invalid secret key size: ${secret.length}. Expected 32 or 64 bytes`); })();

  try {
    logger.info('Starting auto donation from target wallet...');

    // 获取目标钱包信息（发送方）
    const targetWallet = await prisma.wallet.findFirst({
      where: { type: 'target' }
    });

    if (!targetWallet) {
      throw new Error('Target wallet not found in database');
    }

    // 获取慈善钱包信息（接收方）
    const donationWallet = await prisma.wallet.findFirst({
      where: { type: 'donation' }
    });

    if (!donationWallet) {
      throw new Error('Donation wallet not found in database');
    }

    const targetPubkey = new PublicKey(targetWallet.address);
    const balance = await connection.getBalance(targetPubkey);
    const solBalance = balance / LAMPORTS_PER_SOL;

    // 检查目标钱包是否有足够的SOL进行捐赠
    if (solBalance < 0.01) { // 至少需要0.01 SOL作为手续费
      logger.warn(`Insufficient SOL balance in target wallet for donation. Available: ${solBalance}`);
      return { success: false, error: 'Insufficient target wallet balance' };
    }

    // 计算可捐赠的金额（保留0.01 SOL作为手续费）
    const donationAmount = Math.max(0, solBalance - 0.01);

    if (donationAmount <= 0) {
      logger.warn(`No SOL available for donation after reserving fees. Balance: ${solBalance}`);
      return { success: false, error: 'No SOL available for donation' };
    }

    // 获取 SOL 价格
    const solPriceUsd = await getSolPriceUsd();
    const usdValue = donationAmount * solPriceUsd;

    logger.info(`Donating ${donationAmount.toFixed(6)} SOL ($${usdValue.toFixed(2)}) to charity from target wallet`);

    // 创建转账交易（从目标钱包到慈善钱包）
    const donationPubkey = new PublicKey(donationWallet.address);
    const transaction = new Transaction().add(
      SystemProgram.transfer({
        fromPubkey: targetPubkey,
        toPubkey: donationPubkey,
        lamports: Math.floor(donationAmount * LAMPORTS_PER_SOL)
      })
    );

    // 获取最近的 blockhash
    const { blockhash } = await connection.getLatestBlockhash();
    transaction.recentBlockhash = blockhash;
    transaction.feePayer = targetPubkey;

    // 签名并发送交易（使用目标钱包私钥）
    const signature = await connection.sendTransaction(transaction, [targetKeypair]);

    // 等待确认
    await connection.confirmTransaction(signature);

    logger.info(`Donation completed: ${signature}`);

    // 记录到数据库
    await prisma.donation.create({
      data: {
        txSig: signature,
        fromAddress: targetWallet.address, // 从目标钱包地址
        toAddress: donationWallet.address,
        amountSol: donationAmount,
        usdValue,
        note: 'Auto donation from target wallet after threshold swap'
      }
    });

    // 记录交易记录
    await prisma.txRecord.create({
      data: {
        kind: 'donation',
        txSig: signature,
        status: 'success',
        amountUi: donationAmount,
        fromAddress: targetWallet.address, // 从目标钱包地址
        toAddress: donationWallet.address,
        details: JSON.stringify({
          solAmount: donationAmount,
          usdValue,
          method: 'target_wallet_donation'
        })
      }
    });

    // 失效钱包资产缓存，确保数据及时更新
    try {
      const { invalidateWalletAssetsCache } = await import('../index');
      invalidateWalletAssetsCache();
      logger.info('Wallet assets cache invalidated after auto donation');
    } catch (error) {
      logger.warn('Failed to invalidate wallet assets cache:', error);
    }

    // 触发WebSocket余额更新
    try {
      const { webSocketService } = await import('./websocketService');
      await webSocketService.triggerBalanceUpdate();
      logger.info('WebSocket balance update triggered after auto donation');
    } catch (error) {
      logger.warn('Failed to trigger WebSocket balance update:', error);
    }

    // 更新指标
    await prisma.metric.upsert({
      where: { id: '1' },
      update: {
        cumulativeDonations: {
          increment: usdValue,
        },
        lastDonationTimestamp: new Date(),
      },
      create: {
        id: '1',
        cumulativeDonations: usdValue,
        lastDonationTimestamp: new Date(),
      },
    });

    return {
      success: true,
      txSignature: signature,
      amount: donationAmount,
      usdValue: usdValue
    };

  } catch (error) {
    logger.error('Auto donation failed:', error);
    // 记录失败到数据库
    await prisma.txRecord.create({
      data: {
        kind: 'donation',
        txSig: `failed_${randomUUID()}`,
        status: 'failed',
        details: JSON.stringify({ error: (error as Error).message })
      }
    });
    return { success: false, error: (error as Error).message };
  }
}

export async function executeAutoDonationWithRetry(): Promise<DonationResult> {
  return pRetry(
    () => executeAutoDonation(),
    {
      retries: 3,
      factor: 2,
      minTimeout: 1000,
      maxTimeout: 10000,
      onFailedAttempt: (error) => {
        logger.warn(`Auto donation attempt ${error.attemptNumber} failed:`, error.message);
      }
    }
  );
}