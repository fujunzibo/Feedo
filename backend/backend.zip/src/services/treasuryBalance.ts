import { 
  Connection, 
  PublicKey, 
  LAMPORTS_PER_SOL
} from '@solana/web3.js';
import { 
  getAssociatedTokenAddress, 
  getAccount,
  getMint,
  TOKEN_PROGRAM_ID
} from '@solana/spl-token';
import { getConnection } from '../solana/clients';
import { logger } from '../lib/logger';
import { prisma } from '../lib/prisma';

// FEEDO代币的mint地址
const FEEDO_MINT = new PublicKey('5n8sDdBMjsLwtLRVpcFrhFcGa4cXdaUiWKKwNyos8fFK');
const SOL_MINT = new PublicKey('So11111111111111111111111111111111111111112');

export interface TreasuryBalance {
  sol: number;
  feudo: number;
}

export interface BalanceCheck {
  sufficient: boolean;
  available: number;
  required: number;
}

export class TreasuryBalanceService {
  private connection: Connection;

  constructor() {
    this.connection = getConnection();
  }

  /**
   * 获取treasury钱包余额
   */
  async getTreasuryBalance(): Promise<TreasuryBalance> {
    try {
      // 获取treasury钱包
      const treasuryWallet = await prisma.wallet.findFirst({
        where: { type: 'treasury' }
      });

      if (!treasuryWallet) {
        logger.error('Treasury wallet not found');
        return { sol: 0, feudo: 0 };
      }

      const treasuryPubkey = new PublicKey(treasuryWallet.address);

      // 获取SOL余额
      const solBalance = await this.connection.getBalance(treasuryPubkey);
      const solAmount = solBalance / LAMPORTS_PER_SOL;

      // 获取FEEDO代币余额
      let feudoAmount = 0;
      try {
        const feudoTokenAccount = await getAssociatedTokenAddress(
          FEEDO_MINT,
          treasuryPubkey,
          true
        );

        const accountInfo = await getAccount(this.connection, feudoTokenAccount);
        const mintInfo = await getMint(this.connection, FEEDO_MINT);
        feudoAmount = Number(accountInfo.amount) / Math.pow(10, mintInfo.decimals);
      } catch (error) {
        logger.warn('Treasury FEEDO token account not found or error:', error);
        feudoAmount = 0;
      }

      logger.info('Treasury balance retrieved:', { sol: solAmount, feudo: feudoAmount });
      return { sol: solAmount, feudo: feudoAmount };

    } catch (error) {
      logger.error('Failed to get treasury balance:', error);
      return { sol: 0, feudo: 0 };
    }
  }

  /**
   * 检查treasury是否有足够的代币余额
   */
  async checkTreasurySufficientBalance(
    token: 'SOL' | 'FEEDO',
    requiredAmount: number
  ): Promise<BalanceCheck> {
    try {
      const balance = await this.getTreasuryBalance();
      const available = token === 'SOL' ? balance.sol : balance.feudo;

      return {
        sufficient: available >= requiredAmount,
        available,
        required: requiredAmount
      };

    } catch (error) {
      logger.error('Failed to check treasury sufficient balance:', error);
      return {
        sufficient: false,
        available: 0,
        required: requiredAmount
      };
    }
  }

  /**
   * 获取所有钱包的余额
   */
  async getAllWalletBalances(): Promise<{
    treasury: TreasuryBalance;
    wallets: Array<{
      id: string;
      address: string;
      type: string;
      balance: TreasuryBalance;
    }>;
  }> {
    try {
      // 获取treasury余额
      const treasuryBalance = await this.getTreasuryBalance();

      // 获取所有钱包
      const wallets = await prisma.wallet.findMany({
        where: {
          type: {
            in: ['target', 'donation']
          }
        }
      });

      // 获取每个钱包的余额
      const walletBalances = await Promise.all(
        wallets.map(async (wallet) => {
          const walletPubkey = new PublicKey(wallet.address);

          // 获取SOL余额
          const solBalance = await this.connection.getBalance(walletPubkey);
          const solAmount = solBalance / LAMPORTS_PER_SOL;

          // 获取FEEDO代币余额
          let feudoAmount = 0;
          try {
            const feudoTokenAccount = await getAssociatedTokenAddress(
              FEEDO_MINT,
              walletPubkey,
              true
            );

            const accountInfo = await getAccount(this.connection, feudoTokenAccount);
            const mintInfo = await getMint(this.connection, FEEDO_MINT);
            feudoAmount = Number(accountInfo.amount) / Math.pow(10, mintInfo.decimals);
          } catch (error) {
            // 代币账户不存在
            feudoAmount = 0;
          }

          return {
            id: wallet.id,
            address: wallet.address,
            type: wallet.type,
            balance: { sol: solAmount, feudo: feudoAmount }
          };
        })
      );

      return {
        treasury: treasuryBalance,
        wallets: walletBalances
      };

    } catch (error) {
      logger.error('Failed to get all wallet balances:', error);
      return {
        treasury: { sol: 0, feudo: 0 },
        wallets: []
      };
    }
  }

  /**
   * 获取特定钱包的代币余额
   */
  async getWalletTokenBalance(
    walletAddress: string,
    token: 'SOL' | 'FEEDO'
  ): Promise<number> {
    try {
      const walletPubkey = new PublicKey(walletAddress);

      if (token === 'SOL') {
        const balance = await this.connection.getBalance(walletPubkey);
        return balance / LAMPORTS_PER_SOL;
      } else {
        // FEEDO代币
        const feudoTokenAccount = await getAssociatedTokenAddress(
          FEEDO_MINT,
          walletPubkey,
          true
        );

        try {
          const accountInfo = await getAccount(this.connection, feudoTokenAccount);
          const mintInfo = await getMint(this.connection, FEEDO_MINT);
          return Number(accountInfo.amount) / Math.pow(10, mintInfo.decimals);
        } catch (error) {
          return 0;
        }
      }

    } catch (error) {
      logger.error('Failed to get wallet token balance:', error);
      return 0;
    }
  }

  /**
   * 检查钱包是否有足够的代币余额
   */
  async checkWalletSufficientBalance(
    walletAddress: string,
    token: 'SOL' | 'FEEDO',
    requiredAmount: number
  ): Promise<BalanceCheck> {
    try {
      const available = await this.getWalletTokenBalance(walletAddress, token);

      return {
        sufficient: available >= requiredAmount,
        available,
        required: requiredAmount
      };

    } catch (error) {
      logger.error('Failed to check wallet sufficient balance:', error);
      return {
        sufficient: false,
        available: 0,
        required: requiredAmount
      };
    }
  }
}

export const treasuryBalanceService = new TreasuryBalanceService();
