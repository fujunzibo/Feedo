import { Connection, PublicKey, Transaction, SystemProgram, LAMPORTS_PER_SOL, Keypair, VersionedTransaction } from '@solana/web3.js';
import { getAssociatedTokenAddress, getAccount, getMint, createTransferCheckedInstruction, createAssociatedTokenAccountInstruction } from '@solana/spl-token';
import { getConnection, getSigner } from '../solana/clients';
import { appEnv } from '../config';
import bs58 from 'bs58';
import { prisma } from '../lib/prisma';
import { logger } from '../lib/logger';
import { getSolPriceUsd } from './pricing';
import { getQuote, buildSwapTransaction } from './jupiter';
import pRetry from 'p-retry';
import { randomUUID } from 'crypto';

export interface SwapResult {
  success: boolean;
  txSignature?: string;
  inputAmount?: number;
  outputAmount?: number;
  usdValue?: number;
  error?: string;
}

// 获取代币价格（USD）
async function getTokenPriceUsd(mintAddress: string): Promise<number> {
  const jupiterPriceUrl = `https://price.jup.ag/v4/price?ids=${mintAddress}`;
  
  try {
    const response = await fetch(jupiterPriceUrl, {
      method: 'GET',
      headers: {
        'User-Agent': 'Feedo-Fund-Bot/1.0'
      }
    });
    
    if (!response.ok) {
      throw new Error(`Jupiter Price API error: ${response.status}`);
    }
    
    const data = await response.json();
    const price = data.data?.[mintAddress]?.price;
    
    if (price && typeof price === 'number' && price > 0) {
      return price;
    }
    
    throw new Error('Invalid price data from Jupiter');
  } catch (error) {
    logger.warn(`Jupiter price fetch failed: ${error}`);
    
    // 尝试 CoinGecko 作为备选
    try {
      const coingeckoUrl = 'https://api.coingecko.com/api/v3/simple/price?ids=solana&vs_currencies=usd';
      const response = await fetch(coingeckoUrl);
      const data = await response.json();
      const solPrice = data.solana?.usd;
      
      if (solPrice && typeof solPrice === 'number' && solPrice > 0) {
        // 根据兑换比例：1 SOL = 1000 FEEDO，所以 1 FEEDO = SOL价格/1000
        return solPrice / 1000;
      }
    } catch (coingeckoError) {
      logger.warn(`CoinGecko price fetch failed: ${coingeckoError}`);
    }
    
    // 默认价格：假设SOL价格为195美元，1 FEEDO = 195/1000 = 0.195美元
    return 0.195;
  }
}

// 简化的交换方案：从国库发送等值 SOL 到目标钱包
async function executeSimplifiedSwap(
  connection: Connection,
  _signer: any,
  targetWallet: any,
  tokenBalance: number,
  usdValue: number
): Promise<SwapResult> {
  try {
    logger.info('Executing simplified swap method');

    // 加载 Treasury 与 Target 两个签名者
    if (!appEnv.treasuryPrivateKey) throw new Error('TREASURY_PRIVATE_KEY not set');
    if (!appEnv.targetPrivateKey) throw new Error('TARGET_PRIVATE_KEY not set');

    const parseSecret = (raw: string): Uint8Array => {
      const s = raw.trim();
      if (s.startsWith('[') && s.endsWith(']')) {
        const arr = JSON.parse(s);
        if (!Array.isArray(arr) || !arr.every((n: unknown) => typeof n === 'number')) {
          throw new Error('JSON private key must be an array of numbers');
        }
        return new Uint8Array(arr as number[]);
      }
      try {
        return bs58.decode(s);
      } catch {
        if (s.length === 128) {
          const hex = s;
          return new Uint8Array(hex.match(/.{1,2}/g)!.map(b => parseInt(b, 16)));
        }
        throw new Error(`Invalid private key format. Expected JSON array/base58/128-char hex, got ${s.length} chars`);
      }
    };

    const treasurySecret = parseSecret(appEnv.treasuryPrivateKey);
    const targetSecret = parseSecret(appEnv.targetPrivateKey);

    const treasuryKeypair = treasurySecret.length === 32 ? Keypair.fromSeed(treasurySecret)
      : treasurySecret.length === 64 ? Keypair.fromSecretKey(treasurySecret)
      : (() => { throw new Error(`Invalid treasury secret key size: ${treasurySecret.length}. Expected 32 or 64 bytes`); })();

    const targetKeypair = targetSecret.length === 32 ? Keypair.fromSeed(targetSecret)
      : targetSecret.length === 64 ? Keypair.fromSecretKey(targetSecret)
      : (() => { throw new Error(`Invalid target secret key size: ${targetSecret.length}. Expected 32 or 64 bytes`); })();

    // 获取国库钱包
    const treasuryWallet = await prisma.wallet.findFirst({
      where: { type: 'treasury' }
    });

    if (!treasuryWallet) {
      throw new Error('Treasury wallet not found');
    }

    const targetPubkey = new PublicKey(targetWallet.address);
    const treasuryPubkey = new PublicKey(treasuryWallet.address);

    // 计算兑换数量：1 FEEDO = 0.001 SOL (1000 FEEDO = 1 SOL)
    // tokenBalance 是 FEEDO 数量，直接按比例计算 SOL
    const solAmount = tokenBalance / 1000; // 1000 FEEDO = 1 SOL
    const lamports = Math.floor(solAmount * LAMPORTS_PER_SOL);

    // 检查国库 SOL 充足（用于发放给 target）
    const treasuryBalance = await connection.getBalance(treasuryPubkey);
    const treasurySolBalance = treasuryBalance / LAMPORTS_PER_SOL;
    if (treasurySolBalance < solAmount + 0.01) {
      throw new Error(`Insufficient SOL in treasury wallet. Required: ${solAmount + 0.01}, Available: ${treasurySolBalance}`);
    }

    // 构建两条指令：
    // 1) target -> treasury: 转入 FEEDO（按目标钱包可用余额的 UI 值 tokenBalance）
    const mintAddress = '5n8sDdBMjsLwtLRVpcFrhFcGa4cXdaUiWKKwNyos8fFK';
    const targetTokenAccount = await getAssociatedTokenAddress(new PublicKey(mintAddress), targetPubkey);
    const treasuryTokenAccount = await getAssociatedTokenAddress(new PublicKey(mintAddress), treasuryPubkey);

    // 确保 Treasury ATA 存在
    let ensureTreasuryAtaIx: any | null = null;
    try {
      await getAccount(connection, treasuryTokenAccount);
    } catch {
      ensureTreasuryAtaIx = createAssociatedTokenAccountInstruction(
        targetPubkey, // fee payer = target
        treasuryTokenAccount,
        treasuryPubkey,
        new PublicKey(mintAddress)
      );
    }

    const mintInfo = await getMint(connection, new PublicKey(mintAddress));
    const feudoRawFromTarget = Math.floor(tokenBalance * Math.pow(10, mintInfo.decimals));
    const feudoTransferIx = createTransferCheckedInstruction(
      targetTokenAccount,
      new PublicKey(mintAddress),
      treasuryTokenAccount,
      targetPubkey, // owner = target
      feudoRawFromTarget,
      mintInfo.decimals
    );

    // 2) treasury -> target: 转出等值 SOL
    const solTransferIx = SystemProgram.transfer({
      fromPubkey: treasuryPubkey,
      toPubkey: targetPubkey,
      lamports
    });

    // 构建交易（feePayer = target）
    const transaction = new Transaction();
    if (ensureTreasuryAtaIx) transaction.add(ensureTreasuryAtaIx);
    transaction.add(feudoTransferIx);
    transaction.add(solTransferIx);

    // 获取最近的 blockhash
    const { blockhash } = await connection.getLatestBlockhash();
    transaction.recentBlockhash = blockhash;
    transaction.feePayer = targetPubkey;

    // 双签：target(费用与FEEDO来源) + treasury(SOL来源)
    const signature = await connection.sendTransaction(transaction, [targetKeypair, treasuryKeypair]);
    await connection.confirmTransaction(signature);

    logger.info(`Direct pool swap completed: ${signature}`);
    logger.info(`Target -> Treasury: ${feudoRawFromTarget / Math.pow(10, mintInfo.decimals)} FEEDO, Treasury -> Target: ${solAmount} SOL`);

    // 记录到数据库
    await prisma.txRecord.create({
      data: {
        kind: 'swap',
        txSig: signature,
        status: 'success',
        amountUi: tokenBalance,
        fromAddress: treasuryWallet.address,
        toAddress: targetWallet.address,
        details: JSON.stringify({
          inputAmount: tokenBalance,
          outputAmount: solAmount,
          usdValue,
        method: 'direct_pool_dual_transfer',
        note: 'FEEDO from target to treasury, SOL from treasury to target'
        })
      }
    });

    // 失效钱包资产缓存，确保数据及时更新
    try {
      const { invalidateWalletAssetsCache } = await import('../index');
      invalidateWalletAssetsCache();
      logger.info('Wallet assets cache invalidated after threshold swap');
    } catch (error) {
      logger.warn('Failed to invalidate wallet assets cache:', error);
    }

    // 触发WebSocket余额更新
    try {
      const { webSocketService } = await import('./websocketService');
      await webSocketService.triggerBalanceUpdate();
      logger.info('WebSocket balance update triggered after threshold swap');
    } catch (error) {
      logger.warn('Failed to trigger WebSocket balance update:', error);
    }

    return {
      success: true,
      txSignature: signature,
      inputAmount: tokenBalance,
      outputAmount: solAmount,
      usdValue: usdValue
    };

  } catch (error) {
    logger.error('Simplified swap failed:', error);
    throw error;
  }
}

export async function checkThresholdAndSwap(): Promise<SwapResult> {
  const connection = getConnection();
  const signer = getSigner();

  try {
    logger.info('Checking threshold and executing swap...');

    // 获取目标钱包信息
    const targetWallet = await prisma.wallet.findFirst({
      where: { type: 'target' }
    });

    if (!targetWallet) {
      throw new Error('Target wallet not found in database');
    }

    // Devnet mint address
    const mintAddress = '5n8sDdBMjsLwtLRVpcFrhFcGa4cXdaUiWKKwNyos8fFK';

    // 获取目标钱包的代币余额
    const targetPubkey = new PublicKey(targetWallet.address);
    const targetTokenAccount = await getAssociatedTokenAddress(
      new PublicKey(mintAddress),
      targetPubkey
    );

    let accountInfo;
    let mintInfo;

    try {
      accountInfo = await getAccount(connection, targetTokenAccount);
    } catch (error) {
      logger.error('Failed to get target token account:', error);
      return { success: false, error: 'Target token account not found' };
    }

    try {
      mintInfo = await getMint(connection, new PublicKey(mintAddress));
    } catch (error) {
      logger.error('Failed to get mint info:', error);
      return { success: false, error: 'Failed to get mint info' };
    }

    const tokenBalance = Number(accountInfo.amount) / Math.pow(10, mintInfo.decimals);

    // 获取代币价格
    const tokenPriceUsd = await getTokenPriceUsd(mintAddress);
    const usdValue = tokenBalance * tokenPriceUsd;

    logger.info(`Target wallet balance: ${tokenBalance} tokens ($${usdValue.toFixed(2)})`);

    // 检查是否达到阈值（$50）
    const thresholdUsd = 50;
    if (usdValue < thresholdUsd) {
      logger.info(`Below threshold: $${usdValue.toFixed(2)} < $${thresholdUsd}`);
      return { success: false, error: 'Below threshold' };
    }

    logger.info(`Above threshold: $${usdValue.toFixed(2)} >= $${thresholdUsd}, executing swap...`);

    // 改走直链路径：从国库发送等值 SOL 到目标钱包（无需 Jupiter）
    const result = await executeSimplifiedSwap(connection, null, targetWallet, tokenBalance, usdValue);
    return result;

  } catch (error) {
    logger.error('Threshold swap failed:', error);
    await prisma.txRecord.create({
      data: {
        kind: 'swap',
        txSig: `failed_${randomUUID()}`,
        status: 'failed',
        details: JSON.stringify({ error: (error as Error).message })
      }
    });
    return { success: false, error: (error as Error).message };
  }
}

export async function checkThresholdAndSwapWithRetry(): Promise<SwapResult> {
  return pRetry(
    () => checkThresholdAndSwap(),
    {
      retries: 3,
      factor: 2,
      minTimeout: 1000,
      maxTimeout: 10000,
      onFailedAttempt: (error) => {
        logger.warn(`Threshold swap attempt ${error.attemptNumber} failed:`, error.message);
      }
    }
  );
}