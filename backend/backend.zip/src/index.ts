import express from 'express';
import multer from 'multer';
import path from 'path';
import fs from 'fs';
import { appEnv } from './config';
import { scheduleMonthlyTransfer, scheduleThresholdSwap } from './jobs/scheduler';
import { logger } from './lib/logger';
import { executeMonthlyTransferWithRetry } from './services/monthlyTransfer';
import { checkThresholdAndSwap, checkThresholdAndSwapWithRetry } from './services/thresholdSwap';
import { executeAutoDonationWithRetry } from './services/autoDonation';
import { prisma } from './lib/prisma';
import cors from 'cors';
import { PublicKey, LAMPORTS_PER_SOL } from '@solana/web3.js';
import { getAssociatedTokenAddress, getAccount, getMint } from '@solana/spl-token';
import { getConnection } from './solana/clients';
import { getSolPriceUsd } from './services/pricing';
import { realSwapService } from './services/realSwap';
import { webSocketService } from './services/websocketService';

// Get __dirname equivalent for ES modules
import { fileURLToPath } from 'url';
import { dirname } from 'path';
const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);

const app = express();
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(cors({ origin: 'http://localhost:3000' }));

// Serve uploaded media files
app.use('/uploads', express.static(path.join(__dirname, '../uploads')));

// 配置multer用于文件上传
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    const uploadDir = path.join(__dirname, '../uploads/videos');
    if (!fs.existsSync(uploadDir)) {
      fs.mkdirSync(uploadDir, { recursive: true });
    }
    cb(null, uploadDir);
  },
  filename: (req, file, cb) => {
    const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1E9);
    cb(null, `video-${uniqueSuffix}${path.extname(file.originalname)}`);
  }
});

const upload = multer({
  storage: storage,
  limits: {
    fileSize: 100 * 1024 * 1024 // 100MB限制
  },
  fileFilter: (req, file, cb) => {
    if (file.mimetype.startsWith('video/')) {
      cb(null, true);
    } else {
      cb(new Error('Only video files are allowed'));
    }
  }
});

// Media upload configuration (supports both images and videos)
const mediaStorage = multer.diskStorage({
  destination: (req, file, cb) => {
    const fileType = file.mimetype.startsWith('video/') ? 'videos' : 'images';
    const uploadDir = path.join(__dirname, '../uploads', fileType);
    if (!fs.existsSync(uploadDir)) {
      fs.mkdirSync(uploadDir, { recursive: true });
    }
    cb(null, uploadDir);
  },
  filename: (req, file, cb) => {
    const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1E9);
    cb(null, `${file.mimetype.startsWith('video/') ? 'video' : 'image'}-${uniqueSuffix}${path.extname(file.originalname)}`);
  }
});

const mediaUpload = multer({
  storage: mediaStorage,
  limits: {
    fileSize: 100 * 1024 * 1024 // 100MB limit
  },
  fileFilter: (req, file, cb) => {
    const isVideo = file.mimetype.startsWith('video/');
    const isImage = file.mimetype.startsWith('image/');
    
    if (isVideo || isImage) {
      cb(null, true);
    } else {
      cb(new Error('Only video and image files are allowed'));
    }
  }
});

// Health check route
app.get('/api/health', (_req, res) => {
  res.status(200).json({ status: 'ok', timestamp: new Date().toISOString() });
});

// 添加优化的内存缓存
let walletAssetsCache: any = null;
let cacheTimestamp = 0;
const CACHE_DURATION = 300000; // 5分钟缓存，减少API调用

// 预加载缓存，在服务器启动时就开始加载数据
async function preloadWalletAssets() {
  try {
    logger.info('Preloading wallet assets cache...');
    const wallets = await prisma.wallet.findMany();
    const connection = getConnection();
    const mintAddress = '5n8sDdBMjsLwtLRVpcFrhFcGa4cXdaUiWKKwNyos8fFK';

    const solPriceUsd = await getSolPriceUsd();
    const tokenPriceUsd = solPriceUsd / 1000;
    const mintInfo = await getMint(connection, new PublicKey(mintAddress));
    
    const walletPubkeys = wallets.map(w => new PublicKey(w.address));
    
    // Parallel: Get all SOL balances simultaneously using batch API
    const solAccounts = await connection.getMultipleAccountsInfo(
      walletPubkeys
    );
    const solBalances = solAccounts.map((acc: any) => acc ? acc.lamports : 0);
    
    // Batch: Get all token account addresses (local calculation)
    const tokenAccountAddresses = await Promise.all(
      walletPubkeys.map(async (pubkey) => {
        const tokenAccount = await getAssociatedTokenAddress(
          new PublicKey(mintAddress),
          pubkey
        );
        return tokenAccount;
      })
    );

    // Batch: Get all token account data at once
    const tokenAccountsResponse = await connection.getMultipleAccountsInfo(
      tokenAccountAddresses
    );

    const tokenAccounts = tokenAccountsResponse.map((accountData: any, index: number) => {
      try {
        if (accountData && accountData.data) {
          const balanceData = accountData.data.slice(64, 72);
          const amount = Buffer.from(balanceData).readBigUInt64LE(0);
          
          return {
            accountInfo: {
              amount: amount,
              decimals: mintInfo.decimals
            },
            tokenAccount: tokenAccountAddresses[index].toString()
          };
        }
        return {
          accountInfo: null,
          tokenAccount: tokenAccountAddresses[index].toString()
        };
      } catch (error) {
        return { 
          accountInfo: null, 
          tokenAccount: tokenAccountAddresses[index].toString(),
          error 
        };
      }
    });

    const walletAssets = wallets.map((wallet, index) => {
      try {
        const solBalance = solBalances[index] / LAMPORTS_PER_SOL;
        let tokenBalance = 0;
        if (tokenAccounts[index].accountInfo && tokenAccounts[index].accountInfo.amount) {
          const amount = tokenAccounts[index].accountInfo.amount;
          tokenBalance = Number(amount) / Math.pow(10, mintInfo.decimals);
        }
        
        return {
          id: wallet.id,
          name: wallet.name,
          type: wallet.type,
          address: wallet.address,
          solBalance,
          solBalanceUsd: solBalance * solPriceUsd,
          tokenBalance,
          tokenBalanceUsd: tokenBalance * tokenPriceUsd,
          totalUsd: (solBalance * solPriceUsd) + (tokenBalance * tokenPriceUsd)
        };
      } catch (error) {
        logger.error(`Error processing wallet ${wallet.address}:`, error);
        return {
          id: wallet.id,
          name: wallet.name,
          type: wallet.type,
          address: wallet.address,
          solBalance: 0,
          solBalanceUsd: 0,
          tokenBalance: 0,
          tokenBalanceUsd: 0,
          totalUsd: 0,
          error: 'Failed to process balance'
        };
      }
    });

    walletAssetsCache = walletAssets;
    cacheTimestamp = Date.now();
    logger.info('Wallet assets cache preloaded successfully');
  } catch (error) {
    logger.error('Failed to preload wallet assets cache:', error);
  }
}

// 缓存失效函数
function invalidateWalletAssetsCache() {
  walletAssetsCache = null;
  cacheTimestamp = 0;
  logger.info('Wallet assets cache invalidated');
}

// 导出缓存失效函数供其他模块使用
export { invalidateWalletAssetsCache };

// Wallet assets route
app.get('/api/wallet-assets', async (req, res) => {
  try {
    const forceRefresh = req.query.force === 'true' || req.query.refresh === 'true';
    
    // 检查缓存（除非强制刷新）
    const now = Date.now();
    if (!forceRefresh && walletAssetsCache && (now - cacheTimestamp) < CACHE_DURATION) {
      logger.info('Returning cached wallet assets');
      return res.json({
        success: true,
        wallets: walletAssetsCache,
        timestamp: new Date().toISOString(),
        cached: true
      });
    }
    
    if (forceRefresh) {
      logger.info('Force refresh requested, invalidating cache');
      invalidateWalletAssetsCache();
    }

    logger.info('Fetching fresh wallet assets...');

    const wallets = await prisma.wallet.findMany();
    const connection = getConnection();
    const mintAddress = '5n8sDdBMjsLwtLRVpcFrhFcGa4cXdaUiWKKwNyos8fFK'; // FEEDO token

    // 并行获取SOL价格，避免重复请求
    const solPricePromise = getSolPriceUsd();
    const solPriceUsd = await solPricePromise;
    const tokenPriceUsd = solPriceUsd / 1000; // FEEDO代币价格 = SOL价格 / 1000 (1 SOL = 1000 FEEDO)

    // 优化：一次性获取mintInfo，避免重复请求
    const mintInfo = await getMint(connection, new PublicKey(mintAddress));
    
    // 批量获取所有钱包的SOL余额（使用批量查询减少请求数）
    const walletPubkeys = wallets.map(w => new PublicKey(w.address));
    
    // 使用 getMultipleAccountsInfo 批量获取所有钱包的 SOL 余额
    const solAccounts = await connection.getMultipleAccountsInfo(
      walletPubkeys
    );
    const solBalances = solAccounts.map((acc: any) => acc ? acc.lamports : 0);

    // 批量获取所有钱包的代币账户地址（本地计算，无需网络）
    const tokenAccountAddresses = await Promise.all(
      walletPubkeys.map(async (pubkey) => {
        const tokenAccount = await getAssociatedTokenAddress(
          new PublicKey(mintAddress),
          pubkey
        );
        return tokenAccount;
      })
    );

    // 使用 getMultipleAccountsInfo 批量获取所有代币账户信息
    const tokenAccountsResponse = await connection.getMultipleAccountsInfo(
      tokenAccountAddresses
    );

    const tokenAccounts = tokenAccountsResponse.map((accountData: any, index: number) => {
      try {
        // 对于 SPL 代币账户，需要解析数据
        if (accountData && accountData.data) {
          // SPL Token Account 数据结构：前8字节是 mint，接下来8字节是 owner，然后是余额
          const balanceData = accountData.data.slice(64, 72); // 余额在第64-72字节
          const amount = Buffer.from(balanceData).readBigUInt64LE(0);
          
          return {
            accountInfo: {
              amount: amount,
              decimals: mintInfo.decimals
            },
            tokenAccount: tokenAccountAddresses[index].toString()
          };
        }
        return {
          accountInfo: null,
          tokenAccount: tokenAccountAddresses[index].toString()
        };
      } catch (error) {
        return { 
          accountInfo: null, 
          tokenAccount: tokenAccountAddresses[index].toString(),
          error: error
        };
      }
    });

    // 构建结果
    const walletAssets = wallets.map((wallet, index) => {
      try {
        const solBalance = solBalances[index] / LAMPORTS_PER_SOL;
        
        let tokenBalance = 0;
        if (tokenAccounts[index].accountInfo && tokenAccounts[index].accountInfo.amount) {
          const amount = tokenAccounts[index].accountInfo.amount;
          tokenBalance = Number(amount) / Math.pow(10, mintInfo.decimals);
        }
        
        return {
          id: wallet.id,
          name: wallet.name,
          type: wallet.type,
          address: wallet.address,
          solBalance,
          solBalanceUsd: solBalance * solPriceUsd,
          tokenBalance,
          tokenBalanceUsd: tokenBalance * tokenPriceUsd,
          totalUsd: (solBalance * solPriceUsd) + (tokenBalance * tokenPriceUsd)
        };
      } catch (error) {
        logger.error(`Error processing wallet ${wallet.address}:`, error);
        return {
          id: wallet.id,
          name: wallet.name,
          type: wallet.type,
          address: wallet.address,
          solBalance: 0,
          solBalanceUsd: 0,
          tokenBalance: 0,
          tokenBalanceUsd: 0,
          totalUsd: 0,
          error: 'Failed to process balance'
        };
      }
    });

    // 更新缓存
    walletAssetsCache = walletAssets;
    cacheTimestamp = now;

    res.json({
      success: true,
      wallets: walletAssets,
      timestamp: new Date().toISOString(),
      cached: false
    });
  } catch (error) {
    logger.error('Failed to fetch wallet assets:', error);
    res.status(500).json({ 
      success: false, 
      error: 'Failed to fetch wallet assets' 
    });
  }
});

// Dashboard data route
app.get('/api/dashboard', async (req, res) => {
  try {
    const wallets = await prisma.wallet.findMany();
    
    // 支持分页参数
    const page = parseInt(req.query.page as string) || 1;
    const limit = parseInt(req.query.limit as string) || 500; // 默认显示500条记录
    const skip = (page - 1) * limit;
    
    const txRecords = await prisma.txRecord.findMany({
      orderBy: { createdAt: 'desc' },
      skip: skip,
      take: limit,
    });
    
    // 获取总记录数用于分页
    const totalRecords = await prisma.txRecord.count();
    
    const metrics = await prisma.metric.findFirst();

    res.json({
      wallets,
      txRecords,
      metrics,
      pagination: {
        page,
        limit,
        total: totalRecords,
        totalPages: Math.ceil(totalRecords / limit)
      }
    });
  } catch (error) {
    logger.error('Failed to fetch dashboard data:', error);
    res.status(500).json({ error: 'Failed to fetch dashboard data' });
  }
});

// CSV export route
app.get('/api/export-csv', async (_req, res) => {
  try {
    const txRecords = await prisma.txRecord.findMany({
      orderBy: { createdAt: 'desc' },
    });

    let csv = 'kind,txSig,status,amountUi,fromAddress,toAddress,createdAt,details\n';
    txRecords.forEach(record => {
      csv += `${record.kind},${record.txSig},${record.status},${record.amountUi},${record.fromAddress},${record.toAddress},${record.createdAt.toISOString()},"${JSON.stringify(record.details)}"\n`;
    });

    res.header('Content-Type', 'text/csv');
    res.attachment('transactions.csv');
    res.send(csv);
  } catch (error) {
    logger.error('CSV export error:', error);
    res.status(500).json({ error: 'Export failed' });
  }
});

// 调试路由：手动触发 阈值换币 + 自动捐赠
app.post('/api/debug/trigger-swap-donate', async (_req, res) => {
  try {
    logger.info('[debug] Manual trigger: threshold swap + donation');
    const swapResult = await checkThresholdAndSwap();
    if (!swapResult.success) {
      const msg = swapResult.error && String(swapResult.error).trim().length > 0
        ? swapResult.error
        : 'Unknown swap error. Please check backend logs for details.';
      logger.warn(`[debug] swap step failed: ${msg}`);
      return res.status(400).json({ ok: false, step: 'swap', error: msg });
    }
    const donationResult = await executeAutoDonationWithRetry();
    if (!donationResult.success) {
      return res.status(400).json({ ok: false, step: 'donation', error: donationResult.error, swapTx: swapResult.txSignature });
    }
    return res.json({ ok: true, swapTx: swapResult.txSignature, donationTx: donationResult.txSignature });
  } catch (error) {
    logger.error('[debug] trigger-swap-donate failed', error);
    return res.status(500).json({ ok: false, error: (error as Error).message });
  }
});

// 调试路由：手动触发完整流程（1%转账 + 阈值换币 + 自动捐赠）
app.post('/api/debug/trigger-full-workflow', async (_req, res) => {
  try {
    logger.info('[debug] Manual trigger: full workflow (1% transfer + threshold swap + donation)');
    
    // 步骤1：1%转账
    logger.info('[debug] Step 1: Monthly 1% transfer');
    const transferResult = await executeMonthlyTransferWithRetry();
    if (!transferResult.success) {
      return res.status(400).json({ ok: false, step: 'transfer', error: transferResult.error });
    }
    
    // 步骤2：阈值换币
    logger.info('[debug] Step 2: Threshold swap');
    const swapResult = await checkThresholdAndSwap();
    if (!swapResult.success) {
      return res.status(400).json({ ok: false, step: 'swap', error: swapResult.error, transferTx: transferResult.txSignature });
    }
    
    // 步骤3：自动捐赠
    logger.info('[debug] Step 3: Auto donation');
    const donationResult = await executeAutoDonationWithRetry();
    if (!donationResult.success) {
      return res.status(400).json({ ok: false, step: 'donation', error: donationResult.error, transferTx: transferResult.txSignature, swapTx: swapResult.txSignature });
    }
    
    return res.json({ 
      ok: true, 
      transferTx: transferResult.txSignature, 
      swapTx: swapResult.txSignature, 
      donationTx: donationResult.txSignature 
    });
  } catch (error) {
    logger.error('[debug] trigger-full-workflow failed', error);
    return res.status(500).json({ ok: false, error: (error as Error).message });
  }
});

// 手动缓存失效API
app.post('/api/cache/invalidate', async (_req, res) => {
  try {
    invalidateWalletAssetsCache();
    
    // 同时触发WebSocket更新
    try {
      await webSocketService.triggerBalanceUpdate();
      logger.info('WebSocket balance update triggered after cache invalidation');
    } catch (wsError) {
      logger.warn('Failed to trigger WebSocket update:', wsError);
    }
    
    res.json({
      success: true,
      message: 'Wallet assets cache invalidated and WebSocket update triggered',
      timestamp: new Date().toISOString()
    });
  } catch (error) {
    logger.error('Failed to invalidate cache:', error);
    res.status(500).json({
      success: false,
      error: 'Failed to invalidate cache'
    });
  }
});

// 手动强制更新余额API
app.post('/api/force-update-balances', async (_req, res) => {
  try {
    logger.info('Manual force update balances requested');
    
    // 失效缓存
    invalidateWalletAssetsCache();
    
    // 触发WebSocket更新
    try {
      await webSocketService.triggerBalanceUpdate();
      logger.info('WebSocket balance update triggered manually');
    } catch (wsError) {
      logger.warn('Failed to trigger WebSocket update:', wsError);
    }
    
    res.json({
      success: true,
      message: 'Balance update triggered successfully',
      timestamp: new Date().toISOString()
    });
  } catch (error) {
    logger.error('Failed to force update balances:', error);
    res.status(500).json({
      success: false,
      error: 'Failed to force update balances'
    });
  }
});

// 视频上传API
app.post('/api/upload/video', upload.single('video'), async (req, res) => {
  try {
    if (!req.file) {
      return res.status(400).json({
        success: false,
        error: 'No video file uploaded'
      });
    }

    const videoId = path.basename(req.file.filename, path.extname(req.file.filename));
    const fileSize = req.file.size;
    const originalName = req.file.originalname;
    const mimeType = req.file.mimetype;

    logger.info(`Video uploaded: ${originalName}, Size: ${fileSize} bytes, ID: ${videoId}`);

    // 这里可以将视频信息保存到数据库
    // await prisma.video.create({
    //   data: {
    //     id: videoId,
    //     originalName,
    //     filename: req.file.filename,
    //     mimeType,
    //     size: fileSize,
    //     uploadDate: new Date()
    //   }
    // });

    res.json({
      success: true,
      videoId: videoId,
      filename: req.file.filename,
      originalName: originalName,
      size: fileSize,
      mimeType: mimeType,
      message: 'Video uploaded successfully'
    });

  } catch (error) {
    logger.error('Video upload error:', error);
    res.status(500).json({
      success: false,
      error: 'Failed to upload video'
    });
  }
});

// Media upload API (supports both images and videos)
app.post('/api/upload/media', mediaUpload.single('media'), async (req, res) => {
  try {
    if (!req.file) {
      return res.status(400).json({
        success: false,
        error: 'No media file uploaded'
      });
    }

    const { description } = req.body;
    const fileSize = req.file.size;
    const originalName = req.file.originalname;
    const mimeType = req.file.mimetype;
    const fileType = req.file.mimetype.startsWith('video/') ? 'video' : 'image';
    const filePath = req.file.path;
    const filename = req.file.filename;
    
    // Debug log
    logger.info(`Request body: ${JSON.stringify(req.body)}`);
    logger.info(`Description received: ${description}`);
    
    // Generate URL
    const uploadDir = fileType === 'video' ? 'videos' : 'images';
    const url = `/uploads/${uploadDir}/${filename}`;

    logger.info(`Media uploaded: ${originalName}, Type: ${fileType}, Size: ${fileSize} bytes`);

    // Save to database
    try {
      const media = await prisma.media.create({
        data: {
          filename,
          originalName,
          filePath,
          mimeType,
          fileType,
          size: fileSize,
          description: description || null,
          url
        }
      });

      res.json({
        success: true,
        mediaId: media.id,
        filename: media.filename,
        fileType: media.fileType,
        description: media.description,
        url: media.url
      });
    } catch (dbError) {
      logger.error('Database error:', dbError);
      // Even if DB fails, file is saved, so return success
      res.json({
        success: true,
        mediaId: null,
        filename,
        fileType,
        description: description || null,
        url
      });
    }

  } catch (error) {
    logger.error('Media upload error:', error);
    res.status(500).json({
      success: false,
      error: 'Failed to upload media file'
    });
  }
});

// Get media list API
app.get('/api/media', async (_req, res) => {
  try {
    const mediaList = await prisma.media.findMany({
      orderBy: { uploadedAt: 'desc' }
    });

    res.json({
      success: true,
      media: mediaList
    });
  } catch (error) {
    logger.error('Failed to fetch media:', error);
    res.status(500).json({
      success: false,
      error: 'Failed to fetch media list'
    });
  }
});

// 独立API：每月1%转账
app.post('/api/debug/monthly-transfer', async (_req, res) => {
  try {
    logger.info('[debug] Manual trigger: monthly 1% transfer');
    const transferResult = await executeMonthlyTransferWithRetry();
    
    if (transferResult.success) {
      return res.json({ 
        ok: true, 
        txSignature: transferResult.txSignature,
        message: 'Monthly 1% transfer completed successfully'
      });
    } else {
      return res.status(400).json({ 
        ok: false, 
        error: transferResult.error,
        message: 'Monthly transfer failed'
      });
    }
  } catch (error) {
    logger.error('[debug] monthly-transfer failed', error);
    return res.status(500).json({ ok: false, error: (error as Error).message });
  }
});

// 独立API：阈值换币
app.post('/api/debug/threshold-swap', async (_req, res) => {
  try {
    logger.info('[debug] Manual trigger: threshold swap');
    const swapResult = await checkThresholdAndSwapWithRetry();
    
    if (swapResult.success) {
      return res.json({ 
        ok: true, 
        txSignature: swapResult.txSignature,
        message: 'Threshold swap completed successfully',
        usdValue: swapResult.usdValue,
        inputAmount: swapResult.inputAmount,
        outputAmount: swapResult.outputAmount
      });
    } else {
      return res.status(400).json({ 
        ok: false, 
        error: swapResult.error,
        message: swapResult.error === 'Below threshold' ? 'Below threshold ($50 USD)' : 'Threshold swap failed'
      });
    }
  } catch (error) {
    logger.error('[debug] threshold-swap failed', error);
    return res.status(500).json({ ok: false, error: (error as Error).message });
  }
});

// 独立API：自动捐赠
app.post('/api/debug/auto-donation', async (_req, res) => {
  try {
    logger.info('[debug] Manual trigger: auto donation');
    const donationResult = await executeAutoDonationWithRetry();
    
    if (donationResult.success) {
      return res.json({ 
        ok: true, 
        txSignature: donationResult.txSignature,
        message: 'Auto donation completed successfully',
        amount: donationResult.amount,
        usdValue: donationResult.usdValue
      });
    } else {
      return res.status(400).json({ 
        ok: false, 
        error: donationResult.error,
        message: 'Auto donation failed'
      });
    }
  } catch (error) {
    logger.error('[debug] auto-donation failed', error);
    return res.status(500).json({ ok: false, error: (error as Error).message });
  }
});

// 月度转账任务
scheduleMonthlyTransfer(async () => {
  logger.info('Executing monthly 1% transfer...');
  await executeMonthlyTransferWithRetry();
});

// 阈值换币任务
scheduleThresholdSwap(async () => {
  logger.info('Executing threshold swap...');
  await checkThresholdAndSwapWithRetry();
});

// Exchange tokens route
app.get('/api/exchange/tokens', async (req, res) => {
  try {
    const tokens = [
      {
        mint: 'So11111111111111111111111111111111111111112',
        symbol: 'SOL',
        name: 'Solana',
        decimals: 9,
        logoURI: 'https://raw.githubusercontent.com/solana-labs/token-list/main/assets/mainnet/So11111111111111111111111111111111111111112/logo.png'
      },
      {
        mint: '5n8sDdBMjsLwtLRVpcFrhFcGa4cXdaUiWKKwNyos8fFK',
        symbol: 'FEEDO',
        name: 'Feedo Token',
        decimals: 6,
        logoURI: 'https://raw.githubusercontent.com/solana-labs/token-list/main/assets/mainnet/5n8sDdBMjsLwtLRVpcFrhFcGa4cXdaUiWKKwNyos8fFK/logo.png'
      }
    ];

    res.json({
      success: true,
      tokens
    });
  } catch (error) {
    logger.error('Failed to get tokens:', error);
    res.status(500).json({ error: 'Failed to get tokens' });
  }
});

// Exchange price route
app.get('/api/exchange/price', async (req, res) => {
  try {
    const { tokenId } = req.query;

    if (!tokenId) {
      return res.status(400).json({
        success: false,
        error: 'Missing tokenId parameter'
      });
    }

    let price = 0;
    
    if (tokenId === 'So11111111111111111111111111111111111111112') {
      // SOL price
      price = await getSolPriceUsd();
    } else if (tokenId === '5n8sDdBMjsLwtLRVpcFrhFcGa4cXdaUiWKKwNyos8fFK') {
      // FEEDO price = SOL price / 1000
      const solPrice = await getSolPriceUsd();
      price = solPrice / 1000;
    }

    res.json({
      success: true,
      price
    });
  } catch (error) {
    logger.error('Failed to get token price:', error);
    res.status(500).json({ error: 'Failed to get token price' });
  }
});

// Exchange quote route
app.get('/api/exchange/quote', async (req, res) => {
  try {
    const { fromToken, toToken, amount } = req.query;

    if (!fromToken || !toToken || !amount) {
      return res.status(400).json({
        success: false,
        error: 'Missing required parameters'
      });
    }

    // 获取汇率
    const rate = await realSwapService.getSwapRate(
      fromToken as 'SOL' | 'FEEDO',
      toToken as 'SOL' | 'FEEDO'
    );

    // 计算输出数量
    const inputAmount = parseFloat(amount as string);
    let outputAmount: number;
    let outputAmountRaw: string;

    if (fromToken === 'So11111111111111111111111111111111111111112' && toToken === '5n8sDdBMjsLwtLRVpcFrhFcGa4cXdaUiWKKwNyos8fFK') {
      // SOL -> FEEDO: 1 SOL = 1000 FEEDO
      // 直接使用lamports: 1 SOL lamports = 1000 FEEDO raw units
      outputAmount = inputAmount; // 1:1 比例
      outputAmountRaw = inputAmount.toString(); // 直接使用输入金额
    } else if (fromToken === '5n8sDdBMjsLwtLRVpcFrhFcGa4cXdaUiWKKwNyos8fFK' && toToken === 'So11111111111111111111111111111111111111112') {
      // FEEDO -> SOL: 1000 FEEDO = 1 SOL
      // 直接使用raw units: 1000 FEEDO raw = 1 SOL lamports
      outputAmount = inputAmount; // 1:1 比例
      outputAmountRaw = inputAmount.toString(); // 直接使用输入金额
    } else {
      // 其他情况使用汇率计算
      outputAmount = inputAmount * rate;
      outputAmountRaw = Math.floor(outputAmount * 1e6).toString();
    }

    // 计算滑点
    const slippageBps = 50; // 0.5%

    const quote = {
      inputMint: fromToken,
      outputMint: toToken,
      inputAmount: amount,
      outputAmount: outputAmountRaw,
      outputAmountUi: outputAmount,
      slippageBps,
      routePlan: [],
      isEstimated: false,
      note: `1 ${fromToken === 'So11111111111111111111111111111111111111112' ? 'SOL' : 'FEEDO'} = ${fromToken === 'So11111111111111111111111111111111111111112' ? '1000' : '0.001'} ${toToken === 'So11111111111111111111111111111111111111112' ? 'SOL' : 'FEEDO'}`
    };

    res.json({
      success: true,
      quote
    });
  } catch (error) {
    logger.error('Failed to get quote:', error);
    res.status(500).json({ error: 'Failed to get quote' });
  }
});

// Exchange swap route
app.post('/api/exchange/swap', async (req, res) => {
  try {
    const { fromToken, toToken, amount, slippage, fromWalletId, toWalletId } = req.body;

    if (appEnv.demoMode) {
      return res.json({
        success: true,
        message: '演示模式：需要配置签名者才能执行真实交易。当前为演示环境。',
        demo: true
      });
    }

    // 执行真实的代币兑换
    const swapResult = await realSwapService.executeSwap({
      fromWalletId,
      toWalletId,
      fromToken,
      toToken,
      amount,
      slippage
    });

    res.json(swapResult);
  } catch (error) {
    logger.error('Exchange swap failed:', error);
    res.status(500).json({ error: 'Exchange swap failed' });
  }
});

// Real swap execution route
app.post('/api/swap/execute', async (req, res) => {
  try {
    const { fromWalletId, toWalletId, fromToken, toToken, amount, slippage } = req.body;

    if (!fromWalletId || !toWalletId || !fromToken || !toToken || !amount) {
      return res.status(400).json({
        success: false,
        error: 'Missing required parameters'
      });
    }

    const swapResult = await realSwapService.executeSwap({
      fromWalletId,
      toWalletId,
      fromToken,
      toToken,
      amount,
      slippage
    });

    res.json(swapResult);
  } catch (error) {
    logger.error('Real swap execution failed:', error);
    res.status(500).json({
      success: false,
      error: 'Swap execution failed'
    });
  }
});

// Get swap rate
app.get('/api/swap/rate', async (req, res) => {
  try {
    const { fromToken, toToken } = req.query;

    if (!fromToken || !toToken) {
      return res.status(400).json({
        success: false,
        error: 'Missing fromToken or toToken parameter'
      });
    }

    const rate = await realSwapService.getSwapRate(
      fromToken as 'SOL' | 'FEEDO',
      toToken as 'SOL' | 'FEEDO'
    );

    res.json({
      success: true,
      rate,
      fromToken,
      toToken
    });
  } catch (error) {
    logger.error('Failed to get swap rate:', error);
    res.status(500).json({
      success: false,
      error: 'Failed to get swap rate'
    });
  }
});

// Get wallet token balance
app.get('/api/wallet/:walletId/balance/:token', async (req, res) => {
  try {
    const { walletId, token } = req.params;

    if (!walletId || !token) {
      return res.status(400).json({
        success: false,
        error: 'Missing walletId or token parameter'
      });
    }

    const balance = await realSwapService.getWalletTokenBalance(
      walletId,
      token as 'SOL' | 'FEEDO'
    );

    res.json({
      success: true,
      balance,
      token,
      walletId
    });
  } catch (error) {
    logger.error('Failed to get wallet token balance:', error);
    res.status(500).json({
      success: false,
      error: 'Failed to get wallet token balance'
    });
  }
});

// Get treasury balance
app.get('/api/treasury/balance', async (req, res) => {
  try {
    const { treasuryBalanceService } = await import('./services/treasuryBalance');
    const balance = await treasuryBalanceService.getTreasuryBalance();

    res.json({
      success: true,
      balance
    });
  } catch (error) {
    logger.error('Failed to get treasury balance:', error);
    res.status(500).json({
      success: false,
      error: 'Failed to get treasury balance'
    });
  }
});

// Get all wallet balances
app.get('/api/wallets/balances', async (req, res) => {
  try {
    const { treasuryBalanceService } = await import('./services/treasuryBalance');
    const balances = await treasuryBalanceService.getAllWalletBalances();

    res.json({
      success: true,
      balances
    });
  } catch (error) {
    logger.error('Failed to get all wallet balances:', error);
    res.status(500).json({
      success: false,
      error: 'Failed to get all wallet balances'
    });
  }
});

const server = app.listen(appEnv.port, async () => {
  logger.info(`Feedo Fund Backend listening on :${appEnv.port}`);
  logger.info('Scheduled jobs:');
  logger.info('- Monthly 1% transfer: 1st of every month at 00:00 UTC');
  logger.info('- Threshold swap check: Every 5 minutes');
  
  // 预加载钱包资产缓存
  await preloadWalletAssets();
  
  // 启动WebSocket服务
  logger.info('WebSocket service will be available on port 4001');
});

process.on('SIGTERM', () => {
  logger.info('SIGTERM signal received: closing HTTP server');
  server.close(() => {
    logger.info('HTTP server closed');
    process.exit(0);
  });
});

process.on('unhandledRejection', (reason, promise) => {
  logger.error('Unhandled Rejection at:', promise, 'reason:', reason);
});

process.on('uncaughtException', (error) => {
  logger.error('Uncaught Exception:', error);
  process.exit(1);
});