import { logger } from '../lib/logger';
import { appEnv } from '../config';

async function diagnoseWalletConfig() {
  try {
    logger.info('🔍 Diagnosing wallet configuration...');

    // 检查环境变量
    logger.info('\n=== Environment Variables Check ===');
    const envVars = [
      'TREASURY_WALLET',
      'TREASURY_PRIVATE_KEY',
      'TARGET_WALLET',
      'TARGET_PRIVATE_KEY',
      'DONATION_WALLET',
      'DONATION_PRIVATE_KEY',
      'LOCAL_PRIVATE_KEY'
    ];

    for (const envVar of envVars) {
      const value = process.env[envVar];
      if (value) {
        logger.info(`✅ ${envVar}: ${value.substring(0, 20)}...`);
      } else {
        logger.error(`❌ ${envVar}: Not set`);
      }
    }

    // 检查配置对象
    logger.info('\n=== Configuration Object Check ===');
    logger.info(`Treasury Wallet: ${appEnv.treasuryWallet || 'Not set'}`);
    logger.info(`Treasury Private Key: ${appEnv.treasuryPrivateKey ? 'Set' : 'Not set'}`);
    logger.info(`Target Wallet: ${appEnv.targetWallet || 'Not set'}`);
    logger.info(`Target Private Key: ${appEnv.targetPrivateKey ? 'Set' : 'Not set'}`);
    logger.info(`Donation Wallet: ${appEnv.donationWallet || 'Not set'}`);
    logger.info(`Donation Private Key: ${appEnv.donationPrivateKey ? 'Set' : 'Not set'}`);
    logger.info(`Local Private Key: ${appEnv.localPrivateKey ? 'Set' : 'Not set'}`);

    // 提供解决方案
    logger.info('\n=== Solutions ===');
    
    if (!appEnv.treasuryPrivateKey) {
      logger.warn('❌ TREASURY_PRIVATE_KEY is not set');
      logger.info('To fix this:');
      logger.info('1. Create a .env file in the backend directory');
      logger.info('2. Add the following line:');
      logger.info('   TREASURY_PRIVATE_KEY=[your_treasury_private_key_array]');
      logger.info('3. Replace [your_treasury_private_key_array] with the actual private key array');
      logger.info('4. Restart the server');
    }

    if (!appEnv.treasuryWallet) {
      logger.warn('❌ TREASURY_WALLET is not set');
      logger.info('To fix this:');
      logger.info('1. Add to .env file:');
      logger.info('   TREASURY_WALLET=your_treasury_wallet_address');
    }

    // 检查是否有任何私钥可用
    const hasAnyPrivateKey = appEnv.treasuryPrivateKey || appEnv.targetPrivateKey || appEnv.donationPrivateKey || appEnv.localPrivateKey;
    
    if (!hasAnyPrivateKey) {
      logger.error('❌ No private keys found at all!');
      logger.info('You need to configure at least one private key in your .env file.');
    } else {
      logger.info('✅ At least one private key is configured');
    }

    // 提供.env文件模板
    logger.info('\n=== .env File Template ===');
    logger.info('Create a .env file in the backend directory with:');
    logger.info('');
    logger.info('# Treasury Wallet Configuration');
    logger.info('TREASURY_WALLET=your_treasury_wallet_address_here');
    logger.info('TREASURY_PRIVATE_KEY=[your_treasury_private_key_array_here]');
    logger.info('');
    logger.info('# Target Wallet Configuration');
    logger.info('TARGET_WALLET=your_target_wallet_address_here');
    logger.info('TARGET_PRIVATE_KEY=[your_target_private_key_array_here]');
    logger.info('');
    logger.info('# Donation Wallet Configuration');
    logger.info('DONATION_WALLET=your_donation_wallet_address_here');
    logger.info('DONATION_PRIVATE_KEY=[your_donation_private_key_array_here]');
    logger.info('');
    logger.info('# Main Private Key');
    logger.info('LOCAL_PRIVATE_KEY=[your_main_private_key_array_here]');
    logger.info('');
    logger.info('# Other Configuration');
    logger.info('RPC_URL=https://api.devnet.solana.com');
    logger.info('NODE_ENV=development');
    logger.info('PORT=4000');
    logger.info('DATABASE_URL=file:./dev.db');
    logger.info('DEMO_MODE=false');

  } catch (error) {
    logger.error('Diagnosis failed:', error);
  }
}

// 运行诊断
diagnoseWalletConfig()
  .then(() => {
    logger.info('Diagnosis completed');
    process.exit(0);
  })
  .catch((error) => {
    logger.error('Diagnosis failed:', error);
    process.exit(1);
  });

export { diagnoseWalletConfig };
