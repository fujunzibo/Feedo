import { Keypair } from '@solana/web3.js';
import { logger } from '../lib/logger';
import { prisma } from '../lib/prisma';
import { appEnv } from '../config';

async function fixKeypairMismatch() {
  try {
    logger.info('🔧 Fixing keypair mismatch issue...');

    // 1. 检查当前配置
    logger.info('Step 1: Checking current configuration...');
    
    if (!appEnv.localPrivateKey) {
      logger.error('No LOCAL_PRIVATE_KEY found in environment variables');
      return;
    }

    let privateKeyArray: number[];
    try {
      privateKeyArray = JSON.parse(appEnv.localPrivateKey);
    } catch (error) {
      logger.error('Failed to parse LOCAL_PRIVATE_KEY:', error);
      return;
    }

    const currentKeypair = Keypair.fromSecretKey(new Uint8Array(privateKeyArray));
    const currentPublicKey = currentKeypair.publicKey.toBase58();
    logger.info(`Current public key: ${currentPublicKey}`);

    // 2. 获取Treasury钱包
    const treasuryWallet = await prisma.wallet.findFirst({
      where: { type: 'treasury' }
    });

    if (!treasuryWallet) {
      logger.error('Treasury wallet not found in database');
      return;
    }

    logger.info(`Treasury wallet address: ${treasuryWallet.address}`);

    // 3. 检查是否匹配
    if (currentPublicKey === treasuryWallet.address) {
      logger.info('✅ Private key already matches Treasury wallet address');
      return;
    }

    logger.info('❌ Private key does not match Treasury wallet address');

    // 4. 生成新的Treasury密钥对
    logger.info('Step 2: Generating new Treasury keypair...');
    const newKeypair = Keypair.generate();
    const newPublicKey = newKeypair.publicKey.toBase58();
    const newPrivateKey = Array.from(newKeypair.secretKey);

    logger.info(`New Treasury public key: ${newPublicKey}`);

    // 5. 更新数据库中的Treasury钱包地址
    logger.info('Step 3: Updating Treasury wallet address in database...');
    await prisma.wallet.update({
      where: { id: treasuryWallet.id },
      data: { address: newPublicKey }
    });

    logger.info('✅ Treasury wallet address updated in database');

    // 6. 输出新的配置
    logger.info('\n=== 🔑 New Configuration ===');
    logger.info('Please update your environment variables:');
    logger.info(`LOCAL_PRIVATE_KEY=[${newPrivateKey.join(',')}]`);
    logger.info('\nOr update your .env file:');
    logger.info(`LOCAL_PRIVATE_KEY="[${newPrivateKey.join(',')}]"`);

    logger.info('\n=== 📋 Next Steps ===');
    logger.info('1. Update LOCAL_PRIVATE_KEY with the new private key above');
    logger.info('2. Restart the server: npm run dev');
    logger.info('3. Fund the new Treasury wallet with SOL and FEEDO tokens');
    logger.info(`   Treasury address: ${newPublicKey}`);

    logger.info('\n✅ Keypair mismatch fix completed!');

  } catch (error) {
    logger.error('Failed to fix keypair mismatch:', error);
  }
}

// 运行修复
if (require.main === module) {
  fixKeypairMismatch()
    .then(() => {
      logger.info('Fix script completed');
      process.exit(0);
    })
    .catch((error) => {
      logger.error('Fix script failed:', error);
      process.exit(1);
    });
}

export { fixKeypairMismatch };







