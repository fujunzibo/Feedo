import { realSwapService } from '../services/realSwap';
import { logger } from '../lib/logger';

async function testExchangeRate() {
  try {
    logger.info('🧮 Testing exchange rate calculations...');

    // 测试SOL到FEEDO的汇率
    logger.info('\n=== SOL → FEEDO Rate Test ===');
    const solToFeudoRate = await realSwapService.getSwapRate('SOL', 'FEEDO');
    logger.info(`SOL → FEEDO rate: ${solToFeudoRate}`);
    
    if (Math.abs(solToFeudoRate - 1000) < 0.001) {
      logger.info('✅ SOL → FEEDO rate is correct (1000)');
    } else {
      logger.error(`❌ SOL → FEEDO rate is ${solToFeudoRate}, expected 1000`);
    }

    // 测试FEEDO到SOL的汇率
    logger.info('\n=== FEEDO → SOL Rate Test ===');
    const feudoToSolRate = await realSwapService.getSwapRate('FEEDO', 'SOL');
    logger.info(`FEEDO → SOL rate: ${feudoToSolRate}`);
    
    if (Math.abs(feudoToSolRate - 0.001) < 0.000001) {
      logger.info('✅ FEEDO → SOL rate is correct (0.001)');
    } else {
      logger.error(`❌ FEEDO → SOL rate is ${feudoToSolRate}, expected 0.001`);
    }

    // 测试具体兑换计算
    logger.info('\n=== Exchange Calculation Tests ===');
    const testCases = [
      { sol: 0.3, expectedFeudo: 300 },
      { sol: 1, expectedFeudo: 1000 },
      { sol: 0.001, expectedFeudo: 1 },
      { sol: 10, expectedFeudo: 10000 }
    ];

    for (const testCase of testCases) {
      const actualFeudo = testCase.sol * solToFeudoRate;
      logger.info(`${testCase.sol} SOL → Expected: ${testCase.expectedFeudo} FEEDO, Actual: ${actualFeudo} FEEDO`);
      
      if (Math.abs(actualFeudo - testCase.expectedFeudo) < 0.001) {
        logger.info('✅ Calculation correct');
      } else {
        logger.error('❌ Calculation incorrect');
      }
    }

    // 测试反向兑换计算
    logger.info('\n=== Reverse Exchange Calculation Tests ===');
    const reverseTestCases = [
      { feudo: 300, expectedSol: 0.3 },
      { feudo: 1000, expectedSol: 1 },
      { feudo: 1, expectedSol: 0.001 },
      { feudo: 10000, expectedSol: 10 }
    ];

    for (const testCase of reverseTestCases) {
      const actualSol = testCase.feudo * feudoToSolRate;
      logger.info(`${testCase.feudo} FEEDO → Expected: ${testCase.expectedSol} SOL, Actual: ${actualSol} SOL`);
      
      if (Math.abs(actualSol - testCase.expectedSol) < 0.000001) {
        logger.info('✅ Calculation correct');
      } else {
        logger.error('❌ Calculation incorrect');
      }
    }

    // 测试API端点
    logger.info('\n=== API Endpoint Test ===');
    try {
      const response = await fetch('http://localhost:4000/api/swap/rate?fromToken=SOL&toToken=FEEDO');
      const data = await response.json();
      
      if (data.success) {
        logger.info(`API SOL → FEEDO rate: ${data.rate}`);
        if (Math.abs(data.rate - 1000) < 0.001) {
          logger.info('✅ API rate is correct');
        } else {
          logger.error('❌ API rate is incorrect');
        }
      } else {
        logger.error('❌ API request failed:', data.error);
      }
    } catch (error) {
      logger.error('❌ API test failed:', error);
    }

    logger.info('\n✅ Exchange rate test completed');

  } catch (error) {
    logger.error('Exchange rate test failed:', error);
  }
}

// 运行测试
if (require.main === module) {
  testExchangeRate()
    .then(() => {
      logger.info('Test script completed');
      process.exit(0);
    })
    .catch((error) => {
      logger.error('Test script failed:', error);
      process.exit(1);
    });
}

export { testExchangeRate };







