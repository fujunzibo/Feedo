import { realSwapService } from '../services/realSwap';
import { logger } from '../lib/logger';

async function verifyExchangeRate() {
  try {
    logger.info('Verifying exchange rates...');

    // 测试SOL到FEEDO的汇率
    const solToFeudoRate = await realSwapService.getSwapRate('SOL', 'FEEDO');
    logger.info(`SOL → FEEDO rate: ${solToFeudoRate}`);
    
    if (Math.abs(solToFeudoRate - 1000) < 0.001) {
      logger.info('✅ SOL → FEEDO rate is correct (1000)');
    } else {
      logger.warn(`⚠️  SOL → FEEDO rate is ${solToFeudoRate}, expected 1000`);
    }

    // 测试FEEDO到SOL的汇率
    const feudoToSolRate = await realSwapService.getSwapRate('FEEDO', 'SOL');
    logger.info(`FEEDO → SOL rate: ${feudoToSolRate}`);
    
    if (Math.abs(feudoToSolRate - 0.001) < 0.000001) {
      logger.info('✅ FEEDO → SOL rate is correct (0.001)');
    } else {
      logger.warn(`⚠️  FEEDO → SOL rate is ${feudoToSolRate}, expected 0.001`);
    }

    // 验证反向计算
    const reverseRate = 1 / solToFeudoRate;
    logger.info(`Reverse calculation: 1/${solToFeudoRate} = ${reverseRate}`);
    
    if (Math.abs(reverseRate - feudoToSolRate) < 0.000001) {
      logger.info('✅ Reverse calculation matches FEEDO → SOL rate');
    } else {
      logger.warn('⚠️  Reverse calculation does not match FEEDO → SOL rate');
    }

    // 测试具体兑换计算
    const testAmounts = [0.001, 0.01, 0.1, 1, 10];
    
    logger.info('\n=== Testing exchange calculations ===');
    for (const solAmount of testAmounts) {
      const expectedFeudo = solAmount * 1000;
      const actualFeudo = solAmount * solToFeudoRate;
      
      logger.info(`${solAmount} SOL → Expected: ${expectedFeudo} FEEDO, Actual: ${actualFeudo} FEEDO`);
      
      if (Math.abs(actualFeudo - expectedFeudo) < 0.001) {
        logger.info('✅ Calculation correct');
      } else {
        logger.warn('⚠️  Calculation incorrect');
      }
    }

    logger.info('\n=== Testing reverse exchange calculations ===');
    for (const feudoAmount of [1, 10, 100, 1000, 10000]) {
      const expectedSol = feudoAmount / 1000;
      const actualSol = feudoAmount * feudoToSolRate;
      
      logger.info(`${feudoAmount} FEEDO → Expected: ${expectedSol} SOL, Actual: ${actualSol} SOL`);
      
      if (Math.abs(actualSol - expectedSol) < 0.000001) {
        logger.info('✅ Calculation correct');
      } else {
        logger.warn('⚠️  Calculation incorrect');
      }
    }

    logger.info('\n✅ Exchange rate verification completed');

  } catch (error) {
    logger.error('Exchange rate verification failed:', error);
  }
}

// 运行验证
if (require.main === module) {
  verifyExchangeRate()
    .then(() => {
      logger.info('Verification script completed');
      process.exit(0);
    })
    .catch((error) => {
      logger.error('Verification script failed:', error);
      process.exit(1);
    });
}

export { verifyExchangeRate };







