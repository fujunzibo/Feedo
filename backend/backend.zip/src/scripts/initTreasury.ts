import { Connection, PublicKey, Keypair, LAMPORTS_PER_SOL } from '@solana/web3.js';
import { 
  createMint,
  createAccount,
  mintTo,
  getAssociatedTokenAddress,
  createAssociatedTokenAccountInstruction,
  TOKEN_PROGRAM_ID
} from '@solana/spl-token';
import { getConnection } from '../solana/clients';
import { logger } from '../lib/logger';
import { prisma } from '../lib/prisma';
import { treasuryBalanceService } from '../services/treasuryBalance';

// FEEDO代币的mint地址
const FEEDO_MINT = new PublicKey('5n8sDdBMjsLwtLRVpcFrhFcGa4cXdaUiWKKwNyos8fFK');

async function initTreasury() {
  try {
    logger.info('Initializing treasury...');

    const connection = getConnection();

    // 获取treasury钱包
    const treasuryWallet = await prisma.wallet.findFirst({
      where: { type: 'treasury' }
    });

    if (!treasuryWallet) {
      throw new Error('Treasury wallet not found');
    }

    const treasuryPubkey = new PublicKey(treasuryWallet.address);
    logger.info(`Treasury wallet: ${treasuryWallet.address}`);

    // 检查SOL余额
    const solBalance = await connection.getBalance(treasuryPubkey);
    const solAmount = solBalance / LAMPORTS_PER_SOL;
    logger.info(`Treasury SOL balance: ${solAmount}`);

    // 如果SOL余额不足，提示用户充值
    if (solAmount < 1) {
      logger.warn('⚠️  Treasury SOL balance is low. Please send SOL to treasury wallet for testing.');
      logger.info(`Treasury address: ${treasuryWallet.address}`);
      logger.info('You can send SOL using:');
      logger.info(`solana transfer ${treasuryWallet.address} 1 --from <your-keypair> --url devnet`);
    }

    // 检查FEEDO代币账户
    const feudoTokenAccount = await getAssociatedTokenAddress(
      FEEDO_MINT,
      treasuryPubkey,
      true
    );

    try {
      const accountInfo = await connection.getAccountInfo(feudoTokenAccount);
      if (accountInfo) {
        logger.info('Treasury FEEDO account exists');
      } else {
        logger.info('Creating treasury FEEDO account...');
        
        // 这里需要treasury的私钥来创建账户
        // 在实际使用中，应该通过环境变量获取treasury私钥
        logger.warn('⚠️  Treasury FEEDO account does not exist. Please create it manually or provide treasury private key.');
        logger.info(`FEEDO mint: ${FEEDO_MINT.toBase58()}`);
        logger.info(`Treasury address: ${treasuryWallet.address}`);
      }
    } catch (error) {
      logger.warn('Treasury FEEDO account not found:', error);
    }

    // 获取当前余额
    const balance = await treasuryBalanceService.getTreasuryBalance();
    logger.info('Current treasury balance:', balance);

    // 检查是否有足够的代币进行测试
    if (balance.sol < 0.1) {
      logger.warn('⚠️  Treasury SOL balance is too low for testing. Please send more SOL.');
    }

    if (balance.feudo < 100) {
      logger.warn('⚠️  Treasury FEEDO balance is too low for testing. Please send more FEEDO tokens.');
    }

    logger.info('Treasury initialization completed');

  } catch (error) {
    logger.error('Treasury initialization failed:', error);
  }
}

// 运行初始化
if (require.main === module) {
  initTreasury()
    .then(() => {
      logger.info('Init script completed');
      process.exit(0);
    })
    .catch((error) => {
      logger.error('Init script failed:', error);
      process.exit(1);
    });
}

export { initTreasury };







