import { logger } from '../lib/logger';

async function testExchangeAPI() {
  try {
    logger.info('🧪 Testing Exchange API endpoints...');

    const baseUrl = 'http://localhost:4000';

    // 测试获取代币列表
    logger.info('\n=== Testing /api/exchange/tokens ===');
    try {
      const response = await fetch(`${baseUrl}/api/exchange/tokens`);
      const data = await response.json();
      
      if (data.success) {
        logger.info('✅ Tokens API working');
        logger.info(`Found ${data.tokens.length} tokens:`);
        data.tokens.forEach((token: any) => {
          logger.info(`- ${token.symbol} (${token.name}): ${token.mint}`);
        });
      } else {
        logger.error('❌ Tokens API failed:', data.error);
      }
    } catch (error) {
      logger.error('❌ Tokens API error:', error);
    }

    // 测试获取代币价格
    logger.info('\n=== Testing /api/exchange/price ===');
    const tokens = [
      { mint: 'So11111111111111111111111111111111111111112', symbol: 'SOL' },
      { mint: '5n8sDdBMjsLwtLRVpcFrhFcGa4cXdaUiWKKwNyos8fFK', symbol: 'FEEDO' }
    ];

    for (const token of tokens) {
      try {
        const response = await fetch(`${baseUrl}/api/exchange/price?tokenId=${token.mint}`);
        const data = await response.json();
        
        if (data.success) {
          logger.info(`✅ ${token.symbol} price: $${data.price.toFixed(4)}`);
        } else {
          logger.error(`❌ ${token.symbol} price failed:`, data.error);
        }
      } catch (error) {
        logger.error(`❌ ${token.symbol} price error:`, error);
      }
    }

    // 测试获取报价
    logger.info('\n=== Testing /api/exchange/quote ===');
    const testCases = [
      { fromToken: 'So11111111111111111111111111111111111111112', toToken: '5n8sDdBMjsLwtLRVpcFrhFcGa4cXdaUiWKKwNyos8fFK', amount: '300000000', description: '0.3 SOL -> FEEDO' },
      { fromToken: '5n8sDdBMjsLwtLRVpcFrhFcGa4cXdaUiWKKwNyos8fFK', toToken: 'So11111111111111111111111111111111111111112', amount: '300000000', description: '300 FEEDO -> SOL' },
      { fromToken: 'So11111111111111111111111111111111111111112', toToken: '5n8sDdBMjsLwtLRVpcFrhFcGa4cXdaUiWKKwNyos8fFK', amount: '1000000000', description: '1 SOL -> FEEDO' }
    ];

    for (const testCase of testCases) {
      try {
        const response = await fetch(
          `${baseUrl}/api/exchange/quote?fromToken=${testCase.fromToken}&toToken=${testCase.toToken}&amount=${testCase.amount}`
        );
        const data = await response.json();
        
        if (data.success) {
          const quote = data.quote;
          logger.info(`✅ ${testCase.description}:`);
          logger.info(`  Input: ${quote.inputAmount}`);
          logger.info(`  Output: ${quote.outputAmount}`);
          logger.info(`  Rate: ${quote.note}`);
          
          // 验证汇率计算
          if (testCase.fromToken === 'So11111111111111111111111111111111111111112') {
            // SOL -> FEEDO
            const inputSol = parseFloat(testCase.amount) / 1e9; // 转换为SOL
            const expectedFeudo = inputSol * 1000;
            const actualFeudo = parseFloat(quote.outputAmount) / 1e6; // 转换为FEEDO
            logger.info(`  Expected: ${expectedFeudo} FEEDO, Actual: ${actualFeudo} FEEDO`);
            
            if (Math.abs(actualFeudo - expectedFeudo) < 0.001) {
              logger.info('  ✅ Calculation correct');
            } else {
              logger.error('  ❌ Calculation incorrect');
            }
          }
        } else {
          logger.error(`❌ ${testCase.description} failed:`, data.error);
        }
      } catch (error) {
        logger.error(`❌ ${testCase.description} error:`, error);
      }
    }

    logger.info('\n✅ Exchange API test completed');

  } catch (error) {
    logger.error('Exchange API test failed:', error);
  }
}

// 运行测试
if (require.main === module) {
  testExchangeAPI()
    .then(() => {
      logger.info('Test script completed');
      process.exit(0);
    })
    .catch((error) => {
      logger.error('Test script failed:', error);
      process.exit(1);
    });
}

export { testExchangeAPI };







