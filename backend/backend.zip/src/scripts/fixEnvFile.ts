import { Keypair } from '@solana/web3.js';
import { logger } from '../lib/logger';
import { writeFileSync, readFileSync } from 'fs';
import { join } from 'path';
import bs58 from 'bs58';

async function fixEnvFile() {
  try {
    logger.info('🔧 Fixing .env file...');

    const envPath = join(process.cwd(), '.env');
    const envContent = readFileSync(envPath, 'utf8');
    
    logger.info('Current .env content:');
    logger.info(envContent);

    // 解析当前配置
    const lines = envContent.split('\n');
    const config: Record<string, string> = {};
    
    for (const line of lines) {
      if (line.trim() && !line.startsWith('#')) {
        const [key, ...valueParts] = line.split('=');
        if (key && valueParts.length > 0) {
          const cleanKey = key.trim();
          const cleanValue = valueParts.join('=').trim().replace(/^["']|["']$/g, '');
          config[cleanKey] = cleanValue;
        }
      }
    }

    logger.info('\nParsed configuration:');
    Object.entries(config).forEach(([key, value]) => {
      logger.info(`${key}: ${value.substring(0, 20)}...`);
    });

    // 转换Base58私钥为JSON数组格式
    const convertBase58ToArray = (base58Key: string): string => {
      try {
        const secretKey = bs58.decode(base58Key);
        const keypair = Keypair.fromSecretKey(secretKey);
        const privateKeyArray = Array.from(keypair.secretKey);
        return JSON.stringify(privateKeyArray);
      } catch (error) {
        logger.error(`Failed to convert ${base58Key}:`, error);
        return base58Key;
      }
    };

    // 修复私钥格式
    const privateKeys = [
      'LOCAL_PRIVATE_KEY',
      'TREASURY_PRIVATE_KEY', 
      'TARGET_PRIVATE_KEY',
      'DONATION_PRIVATE_KEY'
    ];

    for (const key of privateKeys) {
      if (config[key]) {
        logger.info(`Converting ${key} from Base58 to JSON array...`);
        const convertedKey = convertBase58ToArray(config[key]);
        config[key] = convertedKey;
        logger.info(`✅ ${key} converted`);
      }
    }

    // 修复变量名错误
    if (config['DONATION__PRIVATE_KEY']) {
      config['DONATION_PRIVATE_KEY'] = config['DONATION__PRIVATE_KEY'];
      delete config['DONATION__PRIVATE_KEY'];
      logger.info('✅ Fixed DONATION_PRIVATE_KEY variable name');
    }

    // 生成新的.env文件内容
    const newEnvContent = `# Solana RPC Configuration
RPC_URL=https://devnet.helius-rpc.com/?api-key=97921435-08fe-45ec-bd0c-815044268d06
NODE_ENV=development
PORT=4000

# Database Configuration
DATABASE_URL=file:./prisma/dev.db

# Treasury Wallet Configuration
TREASURY_WALLET=${config.TREASURY_WALLET || '6mM3eZ1Ne3XgvZMDvdJr2urcBkqWw8XwD5GecWLbpAzN'}
TREASURY_PRIVATE_KEY=${config.TREASURY_PRIVATE_KEY || '[]'}

# Target Wallet Configuration
TARGET_WALLET=${config.TARGET_WALLET || '6ringJBRM45z22WZ7z8Pg1Czs6sgbuLbu6U6uuPXFeht'}
TARGET_PRIVATE_KEY=${config.TARGET_PRIVATE_KEY || '[]'}

# Donation Wallet Configuration
DONATION_WALLET=${config.DONATION_WALLET || 'A8BsT5caNZqaku3ckP2YG7yv8NzJKFg9761zmTmjgij9'}
DONATION_PRIVATE_KEY=${config.DONATION_PRIVATE_KEY || '[]'}

# Main Private Key
LOCAL_PRIVATE_KEY=${config.LOCAL_PRIVATE_KEY || '[]'}

# Token Configuration
MINT_ADDRESS=${config.MINT_ADDRESS || '5n8sDdBMjsLwtLRVpcFrhFcGa4cXdaUiWKKwNyos8fFK'}
TOKEN_NAME=${config.TOKEN_NAME || 'Feedo'}
TOKEN_SYMBOL=${config.TOKEN_SYMBOL || 'FEEDO'}
TOKEN_URI=${config.TOKEN_URI || '001.svg'}

# API Configuration
HELIUS_API_KEY=${config.HELIUS_API_KEY || '97921435-08fe-45ec-bd0c-815044268d06'}
JUPITER_BASE=${config.JUPITER_BASE || 'https://quote-api.jup.ag'}

# Other Configuration
NODE_OPTIONS=${config.NODE_OPTIONS || '--max-old-space-size=4096'}
DEMO_MODE=false
`;

    // 备份原文件
    const backupPath = join(process.cwd(), '.env.backup');
    writeFileSync(backupPath, envContent);
    logger.info(`✅ Original .env backed up to .env.backup`);

    // 写入新文件
    writeFileSync(envPath, newEnvContent);
    logger.info('✅ .env file updated');

    logger.info('\n=== Updated Configuration ===');
    logger.info('Treasury Wallet:', config.TREASURY_WALLET);
    logger.info('Target Wallet:', config.TARGET_WALLET);
    logger.info('Donation Wallet:', config.DONATION_WALLET);
    logger.info('All private keys converted to JSON array format');

    logger.info('\n=== Next Steps ===');
    logger.info('1. Restart the server: npm run dev');
    logger.info('2. Test the configuration: npm run diagnose-wallet-config');
    logger.info('3. Test treasury swap: npm run test-treasury-swap');

  } catch (error) {
    logger.error('Failed to fix .env file:', error);
  }
}

// 运行修复
fixEnvFile()
  .then(() => {
    logger.info('Fix script completed');
    process.exit(0);
  })
  .catch((error) => {
    logger.error('Fix script failed:', error);
    process.exit(1);
  });

export { fixEnvFile };
