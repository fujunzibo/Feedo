import { Keypair } from '@solana/web3.js';
import { logger } from '../lib/logger';
import { prisma } from '../lib/prisma';

async function generateTreasuryKeypair() {
  try {
    logger.info('Generating new Treasury keypair...');

    // 生成新的密钥对
    const keypair = Keypair.generate();
    const publicKey = keypair.publicKey.toBase58();
    const privateKey = Array.from(keypair.secretKey);

    logger.info('Generated Treasury keypair:');
    logger.info(`Public Key: ${publicKey}`);
    logger.info(`Private Key: [${privateKey.join(',')}]`);

    // 更新数据库中的Treasury钱包地址
    const treasuryWallet = await prisma.wallet.findFirst({
      where: { type: 'treasury' }
    });

    if (treasuryWallet) {
      await prisma.wallet.update({
        where: { id: treasuryWallet.id },
        data: { address: publicKey }
      });
      logger.info(`Updated Treasury wallet address in database to: ${publicKey}`);
    } else {
      // 创建新的Treasury钱包记录
      await prisma.wallet.create({
        data: {
          name: 'Treasury',
          address: publicKey,
          type: 'treasury'
        }
      });
      logger.info(`Created new Treasury wallet record with address: ${publicKey}`);
    }

    logger.info('\n=== Configuration Update Required ===');
    logger.info('Please update your environment variables:');
    logger.info(`LOCAL_PRIVATE_KEY=[${privateKey.join(',')}]`);
    logger.info('\nOr update your .env file:');
    logger.info(`LOCAL_PRIVATE_KEY="[${privateKey.join(',')}]"`);

    logger.info('\n=== Treasury Wallet Information ===');
    logger.info(`Address: ${publicKey}`);
    logger.info('You can now fund this wallet with SOL and FEEDO tokens for testing.');

    return { publicKey, privateKey };

  } catch (error) {
    logger.error('Failed to generate Treasury keypair:', error);
    throw error;
  }
}

// 运行生成
if (require.main === module) {
  generateTreasuryKeypair()
    .then(() => {
      logger.info('Treasury keypair generation completed');
      process.exit(0);
    })
    .catch((error) => {
      logger.error('Treasury keypair generation failed:', error);
      process.exit(1);
    });
}

export { generateTreasuryKeypair };







