import { Keypair } from '@solana/web3.js';
import { logger } from '../lib/logger';
import { prisma } from '../lib/prisma';
import { writeFileSync, existsSync } from 'fs';
import { join } from 'path';

async function setupTreasury() {
  try {
    logger.info('🔧 Setting up Treasury wallet...');

    // 生成新的Treasury密钥对
    logger.info('Generating new Treasury keypair...');
    const keypair = Keypair.generate();
    const publicKey = keypair.publicKey.toBase58();
    const privateKey = Array.from(keypair.secretKey);

    logger.info(`Treasury public key: ${publicKey}`);
    logger.info(`Treasury private key: [${privateKey.join(',')}]`);

    // 更新数据库中的Treasury钱包地址
    logger.info('Updating Treasury wallet in database...');
    const treasuryWallet = await prisma.wallet.findFirst({
      where: { type: 'treasury' }
    });

    if (treasuryWallet) {
      await prisma.wallet.update({
        where: { id: treasuryWallet.id },
        data: { address: publicKey }
      });
      logger.info('✅ Treasury wallet address updated in database');
    } else {
      await prisma.wallet.create({
        data: {
          name: 'Treasury',
          address: publicKey,
          type: 'treasury'
        }
      });
      logger.info('✅ Treasury wallet created in database');
    }

    // 创建或更新.env文件
    logger.info('Creating/updating .env file...');
    const envPath = join(process.cwd(), '.env');
    
    let envContent = '';
    if (existsSync(envPath)) {
      envContent = require('fs').readFileSync(envPath, 'utf8');
    }

    // 更新或添加Treasury配置
    const treasuryWalletLine = `TREASURY_WALLET=${publicKey}`;
    const treasuryPrivateKeyLine = `TREASURY_PRIVATE_KEY=[${privateKey.join(',')}]`;

    // 检查是否已存在Treasury配置
    if (envContent.includes('TREASURY_WALLET=')) {
      envContent = envContent.replace(/TREASURY_WALLET=.*/g, treasuryWalletLine);
    } else {
      envContent += `\n${treasuryWalletLine}`;
    }

    if (envContent.includes('TREASURY_PRIVATE_KEY=')) {
      envContent = envContent.replace(/TREASURY_PRIVATE_KEY=.*/g, treasuryPrivateKeyLine);
    } else {
      envContent += `\n${treasuryPrivateKeyLine}`;
    }

    // 添加其他必要的配置（如果不存在）
    const requiredConfigs = [
      'RPC_URL=https://api.devnet.solana.com',
      'NODE_ENV=development',
      'PORT=4000',
      'DATABASE_URL=file:./dev.db',
      'DEMO_MODE=false'
    ];

    for (const config of requiredConfigs) {
      const [key] = config.split('=');
      if (!envContent.includes(`${key}=`)) {
        envContent += `\n${config}`;
      }
    }

    writeFileSync(envPath, envContent);
    logger.info('✅ .env file updated');

    logger.info('\n=== Setup Complete ===');
    logger.info('Treasury wallet has been set up successfully!');
    logger.info(`Treasury address: ${publicKey}`);
    logger.info('Private key has been saved to .env file');
    
    logger.info('\n=== Next Steps ===');
    logger.info('1. Fund the Treasury wallet with SOL and FEEDO tokens');
    logger.info(`   Treasury address: ${publicKey}`);
    logger.info('2. Restart the server: npm run dev');
    logger.info('3. Test the setup: npm run test-treasury-swap');

    logger.info('\n=== Funding Instructions ===');
    logger.info('To fund the Treasury wallet:');
    logger.info('1. Send SOL to the Treasury address for transaction fees');
    logger.info('2. Send FEEDO tokens to the Treasury address for swaps');
    logger.info('3. You can use Solana CLI or any wallet to send tokens');

  } catch (error) {
    logger.error('Treasury setup failed:', error);
  }
}

// 运行设置
if (require.main === module) {
  setupTreasury()
    .then(() => {
      logger.info('Setup script completed');
      process.exit(0);
    })
    .catch((error) => {
      logger.error('Setup script failed:', error);
      process.exit(1);
    });
}

export { setupTreasury };







