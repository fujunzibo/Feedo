import { Connection, PublicKey, Keypair } from '@solana/web3.js';
import { getConnection } from '../solana/clients';
import { logger } from '../lib/logger';
import { prisma } from '../lib/prisma';
import { treasuryBalanceService } from '../services/treasuryBalance';
import { realSwapService } from '../services/realSwap';

async function testTreasurySwap() {
  try {
    logger.info('Starting treasury swap test...');

    // 获取连接
    const connection = getConnection();

    // 获取treasury钱包
    const treasuryWallet = await prisma.wallet.findFirst({
      where: { type: 'treasury' }
    });

    if (!treasuryWallet) {
      throw new Error('Treasury wallet not found');
    }

    logger.info(`Treasury wallet: ${treasuryWallet.address}`);

    // 获取treasury余额
    const treasuryBalance = await treasuryBalanceService.getTreasuryBalance();
    logger.info('Treasury balance:', treasuryBalance);

    // 获取所有钱包
    const wallets = await prisma.wallet.findMany();
    logger.info('Available wallets:', wallets.map(w => ({ id: w.id, name: w.name, type: w.type, address: w.address })));

    // 查找用户钱包（非treasury, target, donation）
    const userWallets = wallets.filter(w => !['treasury', 'target', 'donation'].includes(w.type));
    
    if (userWallets.length === 0) {
      logger.warn('No user wallets found for testing');
      return;
    }

    const userWallet = userWallets[0];
    logger.info(`Using user wallet: ${userWallet.name} (${userWallet.address})`);

    // 测试SOL -> FEEDO兑换
    logger.info('\n=== Testing SOL -> FEEDO swap ===');
    
    const solToFeudoRequest = {
      fromWalletId: userWallet.id,
      toWalletId: userWallet.id, // 兑换到同一个钱包
      fromToken: 'SOL' as const,
      toToken: 'FEEDO' as const,
      amount: 0.001, // 0.001 SOL
      slippage: 50
    };

    logger.info('Swap request:', solToFeudoRequest);

    // 检查用户SOL余额
    const userSolBalance = await realSwapService.getWalletTokenBalance(userWallet.id, 'SOL');
    logger.info(`User SOL balance: ${userSolBalance}`);

    if (userSolBalance < 0.001) {
      logger.warn('User has insufficient SOL balance for test');
      return;
    }

    // 检查treasury FEEDO余额
    if (treasuryBalance.feudo < 1) {
      logger.warn('Treasury has insufficient FEEDO balance for test');
      return;
    }

    // 执行兑换
    const swapResult = await realSwapService.executeSwap(solToFeudoRequest);
    logger.info('Swap result:', swapResult);

    if (swapResult.success) {
      logger.info('✅ SOL -> FEEDO swap successful!');
      logger.info(`Transaction signature: ${swapResult.transactionSignature}`);
    } else {
      logger.error('❌ SOL -> FEEDO swap failed:', swapResult.error);
    }

    // 等待一段时间让交易确认
    await new Promise(resolve => setTimeout(resolve, 5000));

    // 获取更新后的余额
    const updatedTreasuryBalance = await treasuryBalanceService.getTreasuryBalance();
    logger.info('Updated treasury balance:', updatedTreasuryBalance);

    // 测试FEEDO -> SOL兑换
    logger.info('\n=== Testing FEEDO -> SOL swap ===');
    
    const feudoToSolRequest = {
      fromWalletId: userWallet.id,
      toWalletId: userWallet.id,
      fromToken: 'FEEDO' as const,
      toToken: 'SOL' as const,
      amount: 0.5, // 0.5 FEEDO
      slippage: 50
    };

    logger.info('Swap request:', feudoToSolRequest);

    // 检查用户FEEDO余额
    const userFeudoBalance = await realSwapService.getWalletTokenBalance(userWallet.id, 'FEEDO');
    logger.info(`User FEEDO balance: ${userFeudoBalance}`);

    if (userFeudoBalance < 0.5) {
      logger.warn('User has insufficient FEEDO balance for test');
      return;
    }

    // 检查treasury SOL余额
    if (updatedTreasuryBalance.sol < 0.0005) {
      logger.warn('Treasury has insufficient SOL balance for test');
      return;
    }

    // 执行兑换
    const swapResult2 = await realSwapService.executeSwap(feudoToSolRequest);
    logger.info('Swap result:', swapResult2);

    if (swapResult2.success) {
      logger.info('✅ FEEDO -> SOL swap successful!');
      logger.info(`Transaction signature: ${swapResult2.transactionSignature}`);
    } else {
      logger.error('❌ FEEDO -> SOL swap failed:', swapResult2.error);
    }

    // 获取最终余额
    const finalTreasuryBalance = await treasuryBalanceService.getTreasuryBalance();
    logger.info('Final treasury balance:', finalTreasuryBalance);

    logger.info('\n=== Test completed ===');

  } catch (error) {
    logger.error('Treasury swap test failed:', error);
  }
}

// 运行测试
testTreasurySwap()
  .then(() => {
    logger.info('Test script completed');
    process.exit(0);
  })
  .catch((error) => {
    logger.error('Test script failed:', error);
    process.exit(1);
  });

export { testTreasurySwap };
