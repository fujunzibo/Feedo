import { Keypair } from '@solana/web3.js';
import { logger } from '../lib/logger';
import { prisma } from '../lib/prisma';
import { appEnv } from '../config';

async function checkKeypairMatch() {
  try {
    logger.info('Checking keypair configuration...');

    // 获取当前配置的私钥
    if (!appEnv.localPrivateKey) {
      logger.error('No LOCAL_PRIVATE_KEY found in environment variables');
      return;
    }

    // 解析私钥
    let privateKeyArray: number[];
    try {
      privateKeyArray = JSON.parse(appEnv.localPrivateKey);
    } catch (error) {
      logger.error('Failed to parse LOCAL_PRIVATE_KEY:', error);
      return;
    }

    // 创建密钥对
    const keypair = Keypair.fromSecretKey(new Uint8Array(privateKeyArray));
    const configuredPublicKey = keypair.publicKey.toBase58();

    logger.info(`Configured private key corresponds to public key: ${configuredPublicKey}`);

    // 获取数据库中的钱包地址
    const wallets = await prisma.wallet.findMany();
    
    logger.info('\n=== Wallet Addresses in Database ===');
    for (const wallet of wallets) {
      logger.info(`${wallet.type}: ${wallet.address}`);
    }

    // 检查匹配
    const treasuryWallet = wallets.find(w => w.type === 'treasury');
    if (treasuryWallet) {
      if (configuredPublicKey === treasuryWallet.address) {
        logger.info('✅ Private key matches Treasury wallet address');
      } else {
        logger.error('❌ Private key does NOT match Treasury wallet address');
        logger.error(`Configured public key: ${configuredPublicKey}`);
        logger.error(`Treasury address: ${treasuryWallet.address}`);
        logger.info('\nTo fix this, you can:');
        logger.info('1. Run: npm run generate-treasury-keypair');
        logger.info('2. Update LOCAL_PRIVATE_KEY with the new private key');
        logger.info('3. Or update the Treasury wallet address in the database');
      }
    } else {
      logger.warn('No Treasury wallet found in database');
    }

    // 检查其他钱包
    const matchingWallet = wallets.find(w => w.address === configuredPublicKey);
    if (matchingWallet) {
      logger.info(`✅ Private key matches ${matchingWallet.type} wallet`);
    } else {
      logger.warn('⚠️  Private key does not match any wallet in database');
    }

  } catch (error) {
    logger.error('Failed to check keypair match:', error);
  }
}

// 运行检查
if (require.main === module) {
  checkKeypairMatch()
    .then(() => {
      logger.info('Keypair check completed');
      process.exit(0);
    })
    .catch((error) => {
      logger.error('Keypair check failed:', error);
      process.exit(1);
    });
}

export { checkKeypairMatch };







