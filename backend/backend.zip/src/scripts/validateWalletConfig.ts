import { Keypair } from '@solana/web3.js';
import { logger } from '../lib/logger';
import { prisma } from '../lib/prisma';
import { appEnv } from '../config';

async function validateWalletConfig() {
  try {
    logger.info('🔍 Validating wallet configuration...');

    // 检查环境变量
    const requiredEnvVars = [
      'TREASURY_WALLET',
      'TREASURY_PRIVATE_KEY',
      'TARGET_WALLET', 
      'TARGET_PRIVATE_KEY',
      'DONATION_WALLET',
      'DONATION_PRIVATE_KEY'
    ];

    logger.info('\n=== Environment Variables Check ===');
    for (const envVar of requiredEnvVars) {
      const value = process.env[envVar];
      if (value) {
        logger.info(`✅ ${envVar}: ${value.substring(0, 20)}...`);
      } else {
        logger.error(`❌ ${envVar}: Not set`);
      }
    }

    // 验证私钥格式和公钥
    logger.info('\n=== Private Key Validation ===');
    
    const walletConfigs = [
      { type: 'treasury', address: appEnv.treasuryWallet, privateKey: appEnv.treasuryPrivateKey },
      { type: 'target', address: appEnv.targetWallet, privateKey: appEnv.targetPrivateKey },
      { type: 'donation', address: appEnv.donationWallet, privateKey: appEnv.donationPrivateKey }
    ];

    for (const config of walletConfigs) {
      logger.info(`\n--- ${config.type.toUpperCase()} Wallet ---`);
      
      if (!config.address) {
        logger.error(`❌ ${config.type} wallet address not set`);
        continue;
      }
      
      if (!config.privateKey) {
        logger.error(`❌ ${config.type} private key not set`);
        continue;
      }

      try {
        // 解析私钥
        const privateKeyArray = JSON.parse(config.privateKey);
        const keypair = Keypair.fromSecretKey(new Uint8Array(privateKeyArray));
        const publicKey = keypair.publicKey.toBase58();
        
        logger.info(`Address: ${config.address}`);
        logger.info(`Public Key: ${publicKey}`);
        
        if (publicKey === config.address) {
          logger.info('✅ Private key matches wallet address');
        } else {
          logger.error('❌ Private key does NOT match wallet address');
        }
        
      } catch (error) {
        logger.error(`❌ Failed to parse ${config.type} private key:`, error);
      }
    }

    // 检查数据库中的钱包配置
    logger.info('\n=== Database Wallet Check ===');
    const dbWallets = await prisma.wallet.findMany();
    
    for (const wallet of dbWallets) {
      logger.info(`${wallet.type}: ${wallet.address}`);
      
      // 检查是否与.env中的配置匹配
      const envConfig = walletConfigs.find(c => c.type === wallet.type);
      if (envConfig && envConfig.address !== wallet.address) {
        logger.warn(`⚠️  Database ${wallet.type} address differs from .env`);
        logger.warn(`Database: ${wallet.address}`);
        logger.warn(`Environment: ${envConfig.address}`);
      }
    }

    // 提供修复建议
    logger.info('\n=== Recommendations ===');
    
    const mismatchedWallets = [];
    for (const config of walletConfigs) {
      if (config.address && config.privateKey) {
        try {
          const privateKeyArray = JSON.parse(config.privateKey);
          const keypair = Keypair.fromSecretKey(new Uint8Array(privateKeyArray));
          if (keypair.publicKey.toBase58() !== config.address) {
            mismatchedWallets.push(config.type);
          }
        } catch (error) {
          mismatchedWallets.push(config.type);
        }
      }
    }

    if (mismatchedWallets.length > 0) {
      logger.warn(`⚠️  Mismatched wallets: ${mismatchedWallets.join(', ')}`);
      logger.info('To fix mismatched wallets:');
      logger.info('1. Check your .env file');
      logger.info('2. Ensure private keys match their corresponding wallet addresses');
      logger.info('3. Update database wallet addresses if needed');
    } else {
      logger.info('✅ All wallet configurations are valid!');
    }

  } catch (error) {
    logger.error('Wallet configuration validation failed:', error);
  }
}

// 运行验证
validateWalletConfig()
  .then(() => {
    logger.info('Validation completed');
    process.exit(0);
  })
  .catch((error) => {
    logger.error('Validation failed:', error);
    process.exit(1);
  });

export { validateWalletConfig };
