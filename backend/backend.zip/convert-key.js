import bs58 from 'bs58';

// 从环境变量文件中的数组格式私钥
const arrayKey = [57,167,106,158,22,53,240,128,173,244,144,6,117,114,93,131,5,57,51,173,159,61,182,151,209,164,126,20,108,236,223,165,65,232,119,188,205,143,128,113,136,35,72,118,7,241,129,122,90,158,73,200,150,248,192,149,147,39,6,239,169,101,77,102];

// 转换为Uint8Array
const uint8Array = new Uint8Array(arrayKey);

// 转换为base58格式
const base58Key = bs58.encode(uint8Array);

console.log('Base58 Private Key:', base58Key);
console.log('Length:', base58Key.length);

// 验证转换是否正确
try {
  const decoded = bs58.decode(base58Key);
  console.log('Decoded length:', decoded.length);
  console.log('Conversion successful!');
} catch (error) {
  console.error('Conversion failed:', error);
}
