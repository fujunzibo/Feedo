-- 查看所有媒体文件及其描述
SELECT 
    id,
    filename,
    originalName,
    description,
    fileType,
    size,
    uploadedAt,
    url
FROM Media
ORDER BY uploadedAt DESC;

-- 查看描述统计
SELECT 
    COUNT(*) as total,
    COUNT(description) as with_description,
    COUNT(*) - COUNT(description) as without_description
FROM Media;

